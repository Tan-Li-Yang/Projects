<?php
$date = isset($_GET["Date"]) ? $_GET["Date"] : "";
$action = isset($_GET["action"]) ? $_GET["action"] : "";
$time = isset($_GET['Time']) ? $_GET['Time'] : '';
$type = isset($_GET['Type']) ? $_GET['Type'] : '';

session_start(); // Start the session
include 'Connect.php';

$user = $_SESSION['userinput'];

$sql = "SELECT role from users WHERE email = '$user';";
$result = mysqli_query($conn, $sql);
$role = ($result && mysqli_num_rows($result) > 0) ? mysqli_fetch_assoc($result)['role'] : '';

// Validate and sanitize input
$date = mysqli_real_escape_string($conn, $date);

switch ($action) {
    case 'bodyweight':
        $sql = "DELETE FROM weight WHERE Date = '$date';";
        $Page = "weight.php";
        break;

    case 'exercise':
        $sql = "DELETE FROM exercise WHERE Date = '$date' AND Type= '$type';";
        $Page = "exercise.php";
        break;

    case 'waterconsumption':
        $sql = "DELETE FROM water WHERE Date = '$date' AND Time = '$time';";
        $Page = "water.php";
        break;

    case 'calory':
        $sql = "DELETE FROM calory WHERE Date = '$date' AND Time = '$time';";
        $Page = "calory.php";
        break;

    case 'request':
        $sql = "DELETE FROM request WHERE Date = '$date' AND Time = '$time';";
        if($role === "user"){
            $Page = "nutritionist.php";
        }else{
            $Page = "admin_dashboard.php";
        }
        
        break;
        
    default:
        echo "<p>Invalid action specified.</p>";
        exit;
}

// Execute the query
if (mysqli_query($conn, $sql)) {
    // Redirect to the previous page
    header("Location: $Page");
    exit();
} else {
    echo "Error: " . mysqli_error($conn);
}

mysqli_close($conn);
?>
