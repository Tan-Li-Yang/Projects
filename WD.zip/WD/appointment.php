<?php
session_start(); // Start the session

if (!isset($_SESSION['userinput'])) {
    // Redirect to login page if not logged in
    header("Location: login.php");
    exit();
}

$bookeddate = [];
$bookedtime = [];
$bookednut = [];

include 'Connect.php';
$sql = "SELECT * FROM request";
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
            $bookeddate[] = $row['Date'];
            $bookedtime[] = $row['Time'];
            $bookednut[] = $row['Nutritionist'];
        }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Booking System</title>
    <link href="https://fonts.googleapis.com/css2?family=Alegreya+Sans:wght@100;300;400&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="appointmentstyle.css">
</head>
<body>

<header>
        <div class="logo">HuanFitnessPal</div>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <?php
                if (!isset($_SESSION['userinput'])) {
                }else{
                    echo '<li><a href="dashhboard.php">Data</a></li>';
                }
                ?>
                <li><a href="aboutus.php">About US</a></li>
                
            </ul>
        </nav>
        <div class="cta-buttons">
            <?php
                if (!isset($_SESSION['userinput'])) {
                    echo '<button class="cta-button"><a href="register.php">Register</a></button>';
                    echo '<button class="cta-button"><a href="login.php">Login</a></button>';
                }else{
                    echo '<button class="cta-button"><a href="logout.php">Sign Out</a></button>';
                }
            ?>
        </div>
    </header>
  
  
    <main>
      <nav class="main-menu">
        <br><br><br>
        <ul>
            <li class="nav-item">
                <b></b>
                <b></b>
                <a href="Dashhboard.php">
                    <i class="fa fa-house nav-icon"></i>
                    <span class="nav-text">Dashboard</span>
                </a>
            </li>
            <li class="nav-item dropdown" id="managementItem">
                <b></b>
                <b></b>
                <a href="#" class="dropdown-toggle">
                  <i class="fa fa-user nav-icon"></i>
                  <span class="nav-text">Management</span>
                  <i class="fa fa-chevron-down dropdown-icon"></i>
              </a>
              <ul class="dropdown-menu">
                  <li><a href="weight.php"><i class="fa fa-weight-scale"></i> Weight</a></li>
                  <li><a href="exercise.php"><i class="fa fa-dumbbell"></i> Exercise</a></li>
                  <li><a href="water.php"><i class="fa fa-glass-water"></i> Water Consumption</a></li>
                  <li><a href="calory.php"><i class="fa fa-cal"></i> Calory</a></li>
                  <li><a href="nutritionist.php"><i class="fa fa-nut"></i> Nutritionist</a></li>
              </ul>
            </li>
            <li class="nav-item active" id="appointmentItem">
                <b></b>
                <b></b>
                <a href="appointment.php" >
                    <i class="fa fa-calendar-check nav-icon"></i>
                    <span class="nav-text">Appointment</span>
                </a>
            </li>
            <li class="nav-item">
                <b></b>
                <b></b>
                <a href="profile.php">
                    <i class="fa fa-calendar-check nav-icon"></i>
                    <span class="nav-text">Profile</span>
                </a>
            </li>
            <li class="nav-item">
                <b></b>
                <b></b>
                <a href="class_booking.php">
                    <i class="fa fa-calendar-check nav-icon"></i>
                    <span class="nav-text">Fitness classes</span>
                </a>
            </li>
        </ul>
    </nav>

        <div class="content-area">
            <div class="wrap">
                <div class="instructions">
                    <div class="first">Choose a Nutritionist</div>
                </div>
                <div class="staff">
                    <!-- Member James Hunter -->
                    <div class="member">
                        <div class="avatar" style="background-image: url(http://i.pravatar.cc/300?img=69)"></div>
                        <div class="name">James Hunter</div>
                        <div class="back-button member-back">Back</div>
                        <div class="back-button date-back">Back</div>
                        <div class="calendar-container">
                            <div class="calendar">
                                <div class="calendar-nav">
                                    <button class="prev-month">&lt;</button>
                                    <span class="current-month-year"></span>
                                    <button class="next-month">&gt;</button>
                                </div>
                                <div class="calendar-days"></div>
                            </div>
                            <div class="slots-container">
                                <ul class="slots"></ul>
                            </div>
                        </div>
                        <button class="confirm-appointment">Confirm Appointment</button>
                    </div>

                    <!-- Member Selena Yamada -->
                    <div class="member">
                        <div class="avatar" style="background-image: url(http://i.pravatar.cc/300?img=25)"></div>
                        <div class="name">Selena Yamada</div>
                        <div class="back-button member-back">Back</div>
                        <div class="back-button date-back">Back</div>
                        <div class="calendar-container">
                            <div class="calendar">
                                <div class="calendar-nav">
                                    <button class="prev-month">&lt;</button>
                                    <span class="current-month-year"></span>
                                    <button class="next-month">&gt;</button>
                                </div>
                                <div class="calendar-days"></div>
                            </div>
                            <div class="slots-container">
                                <ul class="slots"></ul>
                            </div>
                        </div>
                        <button class="confirm-appointment">Confirm Appointment</button>
                    </div>

                    <!-- Member Sarah Belmoris -->
                    <div class="member">
                        <div class="avatar" style="background-image: url(http://i.pravatar.cc/300?img=32)"></div>
                        <div class="name">Sarah Belmoris</div>
                        <div class="back-button member-back">Back</div>
                        <div class="back-button date-back">Back</div>
                        <div class="calendar-container">
                            <div class="calendar">
                                <div class="calendar-nav">
                                    <button class="prev-month">&lt;</button>
                                    <span class="current-month-year"></span>
                                    <button class="next-month">&gt;</button>
                                </div>
                                <div class="calendar-days"></div>
                            </div>
                            <div class="slots-container">
                                <ul class="slots"></ul>
                            </div>
                        </div>
                        <button class="confirm-appointment">Confirm Appointment</button>
                    </div>

                    <!-- Member Phillip Fry -->
                    <div class="member">
                        <div class="avatar" style="background-image: url(http://i.pravatar.cc/300?img=15)"></div>
                        <div class="name">Phillip Fry</div>
                        <div class="back-button member-back">Back</div>
                        <div class="back-button date-back">Back</div>
                        <div class="calendar-container">
                            <div class="calendar">
                                <div class="calendar-nav">
                                    <button class="prev-month">&lt;</button>
                                    <span class="current-month-year"></span>
                                    <button class="next-month">&gt;</button>
                                </div>
                                <div class="calendar-days"></div>
                            </div>
                            <div class="slots-container">
                                <ul class="slots"></ul>
                            </div>
                        </div>
                        <button class="confirm-appointment">Confirm Appointment</button>
                    </div>
                </div>
            </div>

            <form id="UserR" action="add.php" method="post" style="display: none;">
                <input type="hidden" id="Rdate" name="Rdate">
                <input type="hidden" id="Rtime" name="Rtime">
                <input type="hidden" id="nutritionist" name="nutritionist">
            </form>
        </div>
    </main>

    <script src="appointmentjava.js"></script>
</body>
</html>
