<?php
session_start();

// Capture input data
$Identifier = empty($_POST["Id"]) ? "" : $_POST["Id"]; 
$Edate = empty($_POST["Edate"]) ? "" : $_POST["Edate"]; // new date of record
$Odate = empty($_POST["Odate"]) ? "" : $_POST["Odate"]; // old date of record
$Otype = empty($_POST["Otype"]) ? "" : $_POST["Otype"];
$Ostime = empty($_POST["Ostime"]) ? "" : $_POST["Ostime"];
$Otime = empty($_POST["Otime"]) ? "" : $_POST["Otime"];

// Initialize variables for different identifiers
if ($Identifier === "W") { // Weight data
    $weight = empty($_POST["weight"]) ? "" : $_POST["weight"];
    $email = $_SESSION['userinput'];
} elseif ($Identifier === "E") { // Exercise data
    $stime = empty($_POST["stime"]) ? "" : $_POST["stime"];
    $etime = empty($_POST["etime"]) ? "" : $_POST["etime"];
    $type = empty($_POST["type"]) ? "" : $_POST["type"];
    $calory = empty($_POST["calory"]) ? "" : $_POST["calory"];
} elseif ($Identifier === "R") { // Request data
    $Rdate = empty($_POST["Rdate"]) ? "" : $_POST["Rdate"];
    $Rtime = empty($_POST["Rtime"]) ? "" : $_POST["Rtime"];
    $nut = empty($_POST["nut"]) ? "" : $_POST["nut"];
} elseif ($Identifier === "C") { // Request data
    $time = empty($_POST["time"]) ? "" : $_POST["time"];
    $food = empty($_POST["food"]) ? "" : $_POST["food"];
    $calory = empty($_POST["calory"]) ? "" : $_POST["calory"];
} elseif ($Identifier === "T") { // Target data
    $water = empty($_POST["Wtarget"]) ? "" : $_POST["Wtarget"];
    $weight = empty($_POST["Btarget"]) ? "" : $_POST["Btarget"];
    $calory = empty($_POST["Ctarget"]) ? "" : $_POST["Ctarget"];
    $email = $_SESSION['userinput'];
} else { // Water consumption data
    $time = empty($_POST["time"]) ? "" : $_POST["time"];
    $amount = empty($_POST["amount"]) ? "" : $_POST["amount"];
}

// Include database connection
include 'Connect.php'; // Shortcut for creating connection to database

$sql = ""; // Initialize SQL query variable

// Update weight data
if ($Identifier === "W") {
    if ($Edate !== $Odate) {
        // Check if the new date already exists
        $checkSql = "SELECT COUNT(*) as count FROM weight WHERE Date='$Edate' AND email='$email'";
        $checkResult = mysqli_query($conn, $checkSql);
        $row = mysqli_fetch_assoc($checkResult);

        if ($row['count'] > 0) {
            echo "<script type='text/javascript'> alert('Your record are conflicting with another record of $Edate'); window.close(); </script>";
            exit; // Stop execution if there's an error
        } else {
            $sql = "UPDATE weight SET Date='$Edate', Weight='$weight' WHERE Date='$Odate' AND email='$email';";
        }
    } else {
        // If the date hasn't changed, just update the weight
        $sql = "UPDATE weight SET Weight='$weight' WHERE Date='$Odate' AND email='$email';";
    }

} elseif ($Identifier === "E") {
    if ($Edate !== $Odate) {
        // Check if the new date already exists
        $checkSql = "SELECT COUNT(*) as count FROM exercise WHERE Date='$Edate' AND Type='$type' AND Start='$stime'";
        $checkResult = mysqli_query($conn, $checkSql);
        $row = mysqli_fetch_assoc($checkResult);

        if ($row['count'] > 0) {
            echo "<script type='text/javascript'> alert('Your record are conflicting with another record of $Edate'); window.close(); </script>";
            exit; // Stop execution if there's an error
        } else {
            $sql = "UPDATE exercise SET Date='$Edate', Type='$type', Start='$stime', End='$etime', Calory='$calory' 
                    WHERE Date='$Odate' AND Type='$Otype' AND Start='$Ostime';";
        }
    } else {
        // If the date hasn't changed, just update the exercise
        $sql = "UPDATE exercise SET Type='$type', Start='$stime', End='$etime', Calory='$calory' 
                WHERE Date='$Odate' AND Type='$Otype' AND Start='$Ostime';";
    }

} elseif ($Identifier === "R") {
    if ($Rdate !== $Odate) {
        // Check if the new date already exists
        $checkSql = "SELECT COUNT(*) as count FROM request WHERE Date='$Rdate'";
        $checkResult = mysqli_query($conn, $checkSql);
        $row = mysqli_fetch_assoc($checkResult);

        if ($row['count'] > 0) {
            echo "<script type='text/javascript'> alert('Your record are conflicting with another record of $Rdate'); window.close(); </script>";
            exit; // Stop execution if there's an error
        } else {
            $sql = "UPDATE request SET Date='$Rdate', Time='$Rtime', Nutritionist='$nut' WHERE Date='$Odate';";
        }
    } else {
        // If the date hasn't changed, just update the request
        $sql = "UPDATE request SET Time='$Rtime', Nutritionist='$nut' WHERE Date='$Odate';";
    }

} elseif ($Identifier === "C") {
    if ($Edate !== $Odate) {
        // Check if the new date already exists
        $checkSql = "SELECT COUNT(*) as count FROM calory WHERE Date='$Edate' AND Time='$time'";
        $checkResult = mysqli_query($conn, $checkSql);
        $row = mysqli_fetch_assoc($checkResult);

        if ($row['count'] > 0) {
            echo "<script type='text/javascript'> alert('Your record are conflicting with another record of $Edate'); window.close(); </script>";
            exit; // Stop execution if there's an error
        } else {
            $sql = "UPDATE calory SET Date='$Edate', Time='$time', Food='$food', Calory='$calory' WHERE Date='$Odate';";
        }
    } else {
        // If the date hasn't changed, just update the calory intake
        $sql = "UPDATE calory SET Time='$time', Food='$food', Calory='$calory' WHERE Date='$Odate';";
    }

} elseif ($Identifier === "T") {
    $sql = "INSERT INTO target (water, weight, email, Calory) 
            VALUES ('$water','$weight','$email', '$calory') 
            ON DUPLICATE KEY UPDATE 
            water = VALUES(water), 
            weight = VALUES(weight), 
            Calory = VALUES(Calory);";
    header('Location: edit_Target.php');

} else {
    if ($Edate !== $Odate) {
        // Check if the new date already exists
        $checkSql = "SELECT COUNT(*) as count FROM water WHERE Date='$Edate'";
        $checkResult = mysqli_query($conn, $checkSql);
        $row = mysqli_fetch_assoc($checkResult);

        if ($row['count'] > 0) {
            echo "<script type='text/javascript'> alert('Your record are conflicting with another record of $Edate'); window.close(); </script>";
            exit; // Stop execution if there's an error
        } else {
            $sql = "UPDATE water SET Date='$Edate', Time='$time', Amount='$amount' WHERE Date='$Odate';";
        }
    } else {
        // If the date hasn't changed, just update the water consumption
        $sql = "UPDATE water SET Time='$time', Amount='$amount' WHERE Date='$Odate';";
    }
    
}

// Execute the SQL query if it's set
if (!empty($sql)) {
    if (mysqli_query($conn, $sql)) {
        echo "Record updated successfully";
        echo "<script>
                window.opener.location.reload();
                window.close();
              </script>";
    } else {
        echo "Error: " . mysqli_error($conn);
    }
} else {
    echo "No SQL query was generated.";
}

mysqli_close($conn);
?>
