function closeWindow() {
    window.opener.location.reload();
    window.close(); // Close the current window
}

function addBRWindow(action) {
    var width = 540; 
    var height = 188; 

    var left = (screen.width / 2) - (width / 2);
    var top = (screen.height / 2) - (height / 2);

    var url = 'add.php?action=' + action;
    window.open(url, 'editWindow', `width=${width},height=${height},top=${top},left=${left},resizable=no`);
}

function addEWindow(action) {
    var width = 540; 
    var height = 311; 

    var left = (screen.width / 2) - (width / 2);
    var top = (screen.height / 2) - (height / 2);

    var url = 'add.php?action=' + action;
    window.open(url, 'editWindow', `width=${width},height=${height},top=${top},left=${left},resizable=no`);
}

function addWCWindow(action) {
    var width = 540; 
    var height = 231; 

    var left = (screen.width / 2) - (width / 2);
    var top = (screen.height / 2) - (height / 2);

    var url = 'add.php?action=' + action;
    window.open(url, 'editWindow', `width=${width},height=${height},top=${top},left=${left},resizable=no`);
}

function addCWindow(action) {
    var width = 540; 
    var height = 269; 

    var left = (screen.width / 2) - (width / 2);
    var top = (screen.height / 2) - (height / 2);

    var url = 'add.php?action=' + action;
    window.open(url, 'editWindow', `width=${width},height=${height},top=${top},left=${left},resizable=no`);
}


function openBRWindow(email, date, action) {
    var width = 540; 
    var height = 152; 
    var left = (screen.width / 2) - (width / 2);
    var top = (screen.height / 2) - (height / 2);

    // Open edit.php in a new window
    var url = 'edit.php?action=' + action + '&email=' + email + '&Date=' + date;
    window.open(url, 'editWindow', `width=${width},height=${height},top=${top},left=${left},resizable=no`);
}

function openEWindow(email, date, type, action) {
    var width = 540; 
    var height = 274; 
    var left = (screen.width / 2) - (width / 2);
    var top = (screen.height / 2) - (height / 2);

    var url = 'edit.php?action=' + action + '&email=' + email + '&Date=' + date + '&Type=' + type;
    window.open(url, 'editWindow', `width=${width},height=${height},top=${top},left=${left},resizable=no`);
}

function openWCWindow(email, date, time, action) {
    var width = 540; 
    var height = 193; 
    var left = (screen.width / 2) - (width / 2);
    var top = (screen.height / 2) - (height / 2);

    var url = 'edit.php?action=' + action + '&email=' + email + '&Date=' + date + '&Time=' + time;
    window.open(url, 'editWindow', `width=${width},height=${height},top=${top},left=${left},resizable=no`);
}

function openCWindow(email, date, time, action) {
    var width = 540; 
    var height = 250; 
    var left = (screen.width / 2) - (width / 2);
    var top = (screen.height / 2) - (height / 2);

    var url = 'edit.php?action=' + action + '&email=' + email + '&Date=' + date + '&Time=' + time;
    window.open(url, 'editWindow', `width=${width},height=${height},top=${top},left=${left},resizable=no`);
}

function openRWindow(email, date, time, action) {
    var width = 540; 
    var height = 186; 
    var left = (screen.width / 2) - (width / 2);
    var top = (screen.height / 2) - (height / 2);

    // Open edit.php in a new window
    var url = 'edit.php?action=' + action + '&email=' + email + '&Date=' + date + '&Time=' + time;
    window.open(url, 'editWindow', `width=${width},height=${height},top=${top},left=${left},resizable=no`);
}

function updateFinishTimeMin() {
    const startTime = document.getElementById('stime').value; // Get the selected start time
    const finishTimeInput = document.getElementById('etime'); // Get the finish time input field

    if (startTime) {
        // Set the min attribute of the finish time input to the selected start time
        finishTimeInput.min = startTime;
    }
}

// Optional: Validate finish time on form submission
document.getElementById('ERentry').onsubmit = function(e) {
    const startTime = document.getElementById('stime').value;
    const finishTime = document.getElementById('etime').value;

    if (finishTime < startTime) {
        alert("Finish time cannot be earlier than starting time.");
        e.preventDefault(); // Prevent form submission
    }
};

document.addEventListener('DOMContentLoaded', function() {
    loadData();
    loadUpcomingActivities();
});

const navItems = document.querySelectorAll(".nav-item");
navItems.forEach((navItem, i) => {
    navItem.addEventListener("click", () => {
        navItems.forEach((item, j) => {
            item.className = "nav-item";
        });
        navItem.className = "nav-item active";
    });
});

document.addEventListener('DOMContentLoaded', function() {
        const dropdownToggle = document.querySelector('.dropdown-toggle');
        const dropdownItem = document.querySelector('.nav-item.dropdown');

        dropdownToggle.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation(); // Prevent the click from immediately closing the dropdown
            dropdownItem.classList.toggle('active');
        });

        // Close dropdown when clicking outside
        document.addEventListener('click', function(e) {
            if (!dropdownItem.contains(e.target)) {
                dropdownItem.classList.remove('active');
            }
        });

        // Add hover effect to nav items
        const navItems = document.querySelectorAll('.nav-item');
        navItems.forEach(item => {
            item.addEventListener('mouseenter', () => {
                if (!item.classList.contains('active')) {
                    item.style.backgroundColor = 'rgba(255, 255, 255, 0.05)';
                }
            });
            item.addEventListener('mouseleave', () => {
                if (!item.classList.contains('active')) {
                    item.style.backgroundColor = '';
                }
            });
        });

        // Handle clicks on dropdown menu items
        const dropdownMenuItems = document.querySelectorAll('.dropdown-menu a');
        dropdownMenuItems.forEach(item => {
            item.addEventListener('click', (e) => {
                e.stopPropagation(); // Prevent the click from bubbling up and immediately closing the dropdown
            });
        });
    });

    function searchData() {
        const searchDate = document.getElementById('searchInput').value; // Get date from the first input
        const selectedNutritionist = document.getElementById('searchInput2').value; // Get selected nutritionist
        const table = document.getElementById('dataTable');
        const rows = table.getElementsByTagName('tr');
    
        for (let i = 1; i < rows.length; i++) {
            const dateCell = rows[i].getElementsByTagName('td')[0]; // Get the date cell
            const nutritionistCell = rows[i].getElementsByTagName('td')[2]; // Get the nutritionist cell
    
            if (dateCell && nutritionistCell) {
                const rowDate = dateCell.textContent; // Get the date from the row
                const rowNutritionist = nutritionistCell.textContent; // Get the nutritionist from the row
                
                // Check if both date and nutritionist match
                if ((rowDate === searchDate || searchDate === "") && 
                    (rowNutritionist === selectedNutritionist || selectedNutritionist === "All")) {
                    rows[i].style.display = ''; // Show row if matches
                } else {
                    rows[i].style.display = 'none'; // Hide row if it doesn't match
                }
            }
        }
    }

    function searchData2() {
        const searchDate = document.getElementById('searchInput').value; // Get date from the input
        const table = document.getElementById('dataTable');
        const rows = table.getElementsByTagName('tr');
    
        for (let i = 1; i < rows.length; i++) {
            const dateCell = rows[i].getElementsByTagName('td')[0]; // Get the date cell
            
            if (dateCell) {
                const rowDate = dateCell.textContent; // Get the date from the row
                
                // Show row if the row's date matches the search date or if the search date is empty
                if (rowDate === searchDate || searchDate === "") {
                    rows[i].style.display = ''; 
                } else {
                    rows[i].style.display = 'none';
                }
            }
        }
    }

    function searchFoodData() {
        const searchFood = document.getElementById('searchInput2').value.toLowerCase(); // Get the food input and convert to lowercase
        const table = document.getElementById('dataTable');
        const rows = table.getElementsByTagName('tr');
    
        for (let i = 1; i < rows.length; i++) { // Start from 1 to skip the header row
            const foodCell = rows[i].getElementsByTagName('td')[2]; // Get the food cell
            if (foodCell) {
                const rowFood = foodCell.textContent.toLowerCase(); // Get the food text and convert to lowercase
                
                // Check if the row's food matches the search input
                if (rowFood.includes(searchFood) || searchFood === "") {
                    rows[i].style.display = ''; // Show row if matches
                } else {
                    rows[i].style.display = 'none'; // Hide row if it doesn't match
                }
            }
        }
    }
    
    function searchSportsData() {
        const searchSports = document.getElementById('searchInput2').value.toLowerCase(); // Get the sports input and convert to lowercase
        const table = document.getElementById('dataTable');
        const rows = table.getElementsByTagName('tr');
    
        for (let i = 1; i < rows.length; i++) { // Start from 1 to skip the header row
            const sportsCell = rows[i].getElementsByTagName('td')[2]; // Get the sports type cell
            if (sportsCell) {
                const rowSports = sportsCell.textContent.toLowerCase(); // Get the sports type text and convert to lowercase
                
                // Check if the row's sports matches the search input
                if (rowSports.includes(searchSports) || searchSports === "") {
                    rows[i].style.display = ''; // Show row if matches
                } else {
                    rows[i].style.display = 'none'; // Hide row if it doesn't match
                }
            }
        }
    }
    
    
    

    
