<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="style.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="data.js" defer></script>
    <style>
        input[type=number]::-webkit-inner-spin-button,
        input[type=number]::-webkit-outer-spin-button {
            -webkit-appearance: none;
            margin: 0;
        }

        .modal {
            display: block;
            position: fixed;
            z-index: 1;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: hidden;
            background-color: rgba(0, 0, 0, 0.4);
        }

        .modal-content {
            background-color: #fefefe;
            margin: auto;
            padding: 20px;
            border: 1px solid #888;
            width: 100%;
            max-width: 500px;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .request-form {
        display: none; /* Hide the request form */
        }
    </style>
</head>

<body>
<main>
    <?php
    include 'Connect.php';
    session_start(); // Must call session_start() to access session data
    $email = $_SESSION['userinput']; // Access session data
    $action = isset($_GET['action']) ? $_GET['action'] : ''; // Get the action parameter from the URL

    $sql = "SELECT username from users WHERE email = '$email';";
    $result = mysqli_query($conn, $sql);
    $username = ($result && mysqli_num_rows($result) > 0) ? mysqli_fetch_assoc($result)['username'] : '';

    switch ($action) {
        case 'bodyweight': ?>
            <div id="editModal" class="modal">
                <div class="modal-content">
                    <form id="BWentry" name="BWentry" action="add_db.php" method="POST">
                        <label for="Edate">Entry Date</label><br>
                        <input type="date" id="Edate" name="Edate" value="<?= date("Y-m-d") ?>"
                               min="2022-12-31" max="<?php echo date("Y-m-d") ?>"><br><br>

                        <label for="weight">Enter Weight: </label>
                        <input type="number" id="weight" name="weight" placeholder="90kg" step="0.01" required min=1><br><br>

                        <input type="hidden" id="Id" name="Id" value="W" readonly><br>
                        <input type="hidden" id="email" name="email" value="<?=$email?>" readonly><br>
                        <input type="submit" value="Add" id="add" name="add">
                    </form>
                </div>
            </div>
        <?php break;

        case 'exercise': ?>
            <div id="editModal" class="modal">
                <div class="modal-content">
                    <form id="ERentry" name="ERentry" action="add_db.php" method="POST">
                        <label for="Edate">Entry Date</label><br>
                        <input type="date" id="Edate" name="Edate" value="<?= date("Y-m-d") ?>"
                               min="2022-12-31" max="<?php echo date("Y-m-d") ?>"><br><br>

                        <label for="type">Type of exercise: </label>
                        <input type="text" id="type" name="type" required><br><br>

                        <label for="stime">Starting Time:</label>
                        <input type="time" id="stime" name="stime" required onchange="updateFinishTimeMin()"><br><br>

                        <label for="etime">Finish Time:</label>
                        <input type="time" id="etime" name="etime" required><br><br>

                        <label for="calory">Enter Calories burned: </label>
                        <input type="number" id="calory" name="calory" placeholder="kcal" step="0.01" required min=1><br><br>

                        <input type="hidden" id="Id" name="Id" value="E" readonly><br>
                        <input type="hidden" id="email" name="email" value="<?=$email?>" readonly><br>
                        <input type="submit" value="Add" id="add" name="add">
                    </form>
                </div>
            </div>
        <?php break;

        case 'waterconsumption': ?>
            <div id="editModal" class="modal">
                <div class="modal-content">
                    <form id="WCentry" name="WCentry" action="add_db.php" method="POST">
                        <label for="Edate">Entry Date</label><br>
                        <input type="date" id="Edate" name="Edate" value="<?= date("Y-m-d") ?>"
                               min="2022-12-31" max="<?php echo date("Y-m-d") ?>"><br><br>

                        <label for="time">Select Time:</label>
                        <input type="time" id="time" name="time" required><br><br>

                        <label for="amount">Enter Amount: </label>
                        <input type="number" id="amount" name="amount" placeholder="ml" step="0.01" required min=1><br><br>

                        <input type="hidden" id="Id" name="Id" value="" readonly><br>
                        <input type="hidden" id="email" name="email" value="<?=$email?>" readonly><br>
                        <input type="submit" value="Add" id="add" name="add">
                    </form>
                </div>
            </div>
        <?php break;

        case 'calory': ?>
            <div id="editModal" class="modal">
                <div class="modal-content">
                    <form id="Centry" name="Centry" action="add_db.php" method="POST">
                        <label for="Edate">Entry Date</label><br>
                        <input type="date" id="Edate" name="Edate" value="<?= date("Y-m-d") ?>"
                               min="2022-12-31" max="<?php echo date("Y-m-d") ?>"><br><br>

                        <label for="time">Select Time:</label>
                        <input type="time" id="time" name="time" required><br><br>

                        <label for="food">Enter Food:</label>
                        <input type="text" id="food" name="food" required><br><br>

                        <label for="calory">Enter Calory: </label>
                        <input type="number" id="calory" name="calory" placeholder="kcal" step="0.01" required min=1><br><br>

                        <input type="hidden" id="Id" name="Id" value="C" readonly><br>
                        <input type="hidden" id="email" name="email" value="<?=$email?>" readonly><br>
                        <input type="submit" value="Add" id="add" name="add">
                    </form>
                </div>
            </div>
        <?php break;

        case 'request': ?>
            <div id="editModal" class="modal request-form">
                <div class="modal-content">
                    <form id="UserR" name="UserR" action="add_db.php" method="POST">
                        <input type="date" id="Rdate" name="Rdate" value="<?= date("Y-m-d") ?>"
                               min="<?php echo date("Y-m-d") ?>" max="2025-12-31"><br><br>

                        <input type="time" id="Rtime" name="Rtime"><br><br>

                        <input type="text" id="nut" name="nut" readonly><br><br>

                        <input type="hidden" id="Id" name="Id" value="R" readonly><br>
                        <input type="hidden" id="email" name="email" value="<?=$email?>" readonly><br>
                        <input type="hidden" id="Name" name="Name" value="<?=$username?>" readonly><br>

                        <input type="submit" value="Send request" id="send" name="send">
                    </form>
                </div>
            </div>

            <script>
                const storedDate = sessionStorage.getItem('selectedDate');
                const storedTime = sessionStorage.getItem('selectedTime');
                const storedNutritionist = sessionStorage.getItem('nutritionistName');

                if (storedDate && storedTime && storedNutritionist) {
                    document.getElementById('Rdate').value = storedDate;
                    document.getElementById('Rtime').value = storedTime;
                    document.getElementById('nut').value = storedNutritionist;

                    document.getElementById('UserR').submit();

                    sessionStorage.removeItem('selectedDate');
                    sessionStorage.removeItem('selectedTime');
                    sessionStorage.removeItem('nutritionistName');
                }
            </script>
        <?php break;

        default:
            echo "<p>Please select a form from the navigation.</p>";
            break;
    }
    ?>
</main>
</body>
</html>
