<?php
session_start();

$email = $oldUserName = $gender = $old_email = $ph_no = $bdate = "";
$usernameErr = $invalidEmail = $invalidPhoneNo = "";

if (!isset($_SESSION['userinput'])) {
    header("Location: login.php");
    exit();
}

include 'Connect.php';

$userinput = $_SESSION['userinput'];

if (filter_var($userinput, FILTER_VALIDATE_EMAIL)) {
    $email = $userinput;
    $sql = "SELECT * FROM users WHERE email = ?;";
} else {
    $oldUserName = $userinput;
    $sql = "SELECT * FROM users WHERE username = ?;";
}

$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "s", $userinput);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if ($row = mysqli_fetch_assoc($result)) {
    $oldUserName = $row["username"];
    $gender = $row["gender"];
    $old_email = $row["email"];
    $ph_no = $row["phonenumber"];
    $bdate = $row["dob"];
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $newUserName = empty($_POST["username"]) ? "" : $_POST["username"];
    $gender = isset($_POST["gender"]) ? $_POST["gender"] : "";
    $email = $_POST["email"];
    $phone_no = $_POST["phnumber"];
    $dob = empty($_POST["bdate"]) ? "" : $_POST["bdate"];

    // Validate email
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $invalidEmail = "Invalid email format.";
    } else {
        // Validate phone number
        $phone_pattern = "/^\+?(\d{1,3})?\s?(\(?\d{3}\)?)\s?-?\d{3}-?\d{4}$/";
        if (!preg_match($phone_pattern, $phone_no)) {
            $invalidPhoneNo = "Invalid phone number format. E.g., +1 123-456-7890";
        } else {
            // Validate date
            try {
                $dateObj = new DateTime($dob);
                $formattedDate = $dateObj->format('Y-m-d');
            } catch (Exception $e) {
                echo "Invalid date format.";
                exit;
            }

            // Check if there are no validation errors
            if (empty($invalidEmail) && empty($invalidPhoneNo)) {
                if ($newUserName !== $oldUserName) {
                    $check_sql = "SELECT username FROM users WHERE username = ?";
                    $stmt_check = mysqli_prepare($conn, $check_sql);
                    mysqli_stmt_bind_param($stmt_check, 's', $newUserName);
                    mysqli_stmt_execute($stmt_check);
                    mysqli_stmt_store_result($stmt_check);
                    
                    if (mysqli_stmt_num_rows($stmt_check) > 0) {
                        $usernameErr = "Username already exists. Please choose another one.";
                        mysqli_stmt_close($stmt_check);
                    } else {
                        mysqli_stmt_close($stmt_check);

                        // Update username
                        $update_sql = "UPDATE users SET username=? WHERE email=?";
                        $stmt = mysqli_prepare($conn, $update_sql);
                        mysqli_stmt_bind_param($stmt, 'ss', $newUserName, $old_email);
                        if (!mysqli_stmt_execute($stmt)) {
                            echo "Error updating username: " . mysqli_error($conn);
                        }
                        mysqli_stmt_close($stmt);
                    }
                }

                // Update user details
                $update_sql = "UPDATE users SET gender = ?, email = ?, phonenumber = ?, dob = ? WHERE username = ?";
                $stmt = mysqli_prepare($conn, $update_sql);
                mysqli_stmt_bind_param($stmt, 'sssss', $gender, $email, $phone_no, $formattedDate, $newUserName);

                if (mysqli_stmt_execute($stmt)) {
                    echo "Profile updated successfully.";
                    mysqli_stmt_close($stmt);
                    $_SESSION['userinput'] = $newUserName;
                    header("Location: profile.php");
                } else {
                    echo "Error: $sql <br>" . mysqli_error($conn);
                }
                mysqli_close($conn);
            }
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="DashhboardStyle.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        .edit_profile-container {
            width: 60%;
            margin: 50px auto;
            background-color: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        input[type="text"], input[type="email"], input[type="password"], input[type="tel"], select {
            width: 90%;
            padding: 10px;
            margin: 5px 0 15px 0;
            display: inline-block;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        input[type="submit"], .change_password-btn {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-weight: bold;
        }
        .change_password-btn a {
            text-decoration: none;
            padding: 10px 20px;
            background-color: #4CAF50;
            color: white;
            border-radius: 4px;
        }
        input[type="submit"]:hover, .change_password-btn:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <main>
        <nav class="main-menu">
            <br><br><br>
            <ul>
                <li class="nav-item">
                    <a href="Dashhboard.php">
                        <i class="fa fa-house nav-icon"></i>
                        <span class="nav-text">Dashboard</span>
                    </a>
                </li>
                <li class="nav-item dropdown" id="managementItem">
                <b></b>
                <b></b>
                <a href="#" class="dropdown-toggle">
                    <i class="fa fa-user nav-icon"></i>
                    <span class="nav-text">Management</span>
                    <i class="fa fa-chevron-down dropdown-icon"></i>
                </a>
                <ul class="dropdown-menu">
                    <li><a href="weight.php"><i class="fa fa-weight-scale"></i> Weight</a></li>
                    <li><a href="exercise.php"><i class="fa fa-dumbbell"></i> Exercise</a></li>
                    <li><a href="water.php"><i class="fa fa-glass-water"></i> Water Consumption</a></li>
                    <li><a href="calory.php"><i class="fa fa-cal"></i> Calory</a></li>
                    <li><a href="nutritionist.php"><i class="fa fa-nut"></i> Nutritionist</a></li>
                </ul>
            </li>
                <li class="nav-item">
                    <a href="appointment.php">
                        <i class="fa fa-calendar-check nav-icon"></i>
                        <span class="nav-text">Appointment</span>
                    </a>
                </li>
                <li class="nav-item active">
                    <a href="profile.php">
                        <i class="fa fa-calendar-check nav-icon"></i>
                        <span class="nav-text">Profile</span>
                    </a>
                </li>
                <li class="nav-item">
                <b></b>
                <b></b>
                <a href="class_booking.php">
                    <i class="fa fa-calendar-check nav-icon"></i>
                    <span class="nav-text">Fitness classes</span>
                </a>
            </li>
            </ul>
        </nav>

        <div class="edit_profile-container">
            <h2>Edit Profile</h2>
            <form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">
                <label for="username">Username:</label><br>
                <input type="text" name="username" value="<?php echo htmlspecialchars($oldUserName); ?>"><br>
                <span style="color:red;"><?php echo htmlspecialchars($usernameErr); ?></span><br>

                <label for="gender">Gender:</label><br>
                <input type="radio" id="male" name="gender" value="male" <?php echo ($gender === 'male') ? 'checked' : ''; ?>>
                <label for="male">Male</label>
                <input type="radio" id="female" name="gender" value="female" <?php echo ($gender === 'female') ? 'checked' : ''; ?>>
                <label for="female">Female</label><br><br>

                <label for="email">Email:</label><br>
                <input type="email" name="email" value="<?php echo htmlspecialchars($old_email); ?>"><br>
                <span style="color:red;"><?php echo htmlspecialchars($invalidEmail); ?></span><br>

                <label for="phnumber">Phone number:</label><br>
                <input type="tel" id="phnumber" name="phnumber" value="<?php echo htmlspecialchars($ph_no); ?>"><br>
                <span style="color:red;"><?php echo htmlspecialchars($invalidPhoneNo); ?></span><br>

                <label for="bdate">Date of birth:</label><br>
                <input type="date" id="bdate" name="bdate" value="<?php echo htmlspecialchars($bdate); ?>" required><br><br>

                <button class="change_password-btn">
                    <a href="change_password.php">Change password</a>
                </button><br><br>

                <input type="submit" value="Save Changes" name="savechanges">
            </form>
        </div>
    </main>
</body>
</html>

<script src="profile.js" defer></script>
