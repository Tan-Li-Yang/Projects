<?php
session_start(); // Start the session
include 'Connect.php';

$user = $_SESSION['userinput'];

$sql = "SELECT role from users WHERE email = '$user';";
$result = mysqli_query($conn, $sql);
$role = ($result && mysqli_num_rows($result) > 0) ? mysqli_fetch_assoc($result)['role'] : '';

if (!isset($_SESSION['userinput']) OR $role !== "admin") {
    // Redirect to login page if not logged in
    header("Location: login.php");
    exit();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Health App</title>
    <script src="data.js" defer></script>

    <style>
        :root {
            --primary-color: #4a90e2;
            --secondary-color: #f5a623;
            --background-color: #f0f4f8;
            --text-color: #333;
            --border-color: #e0e0e0;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            margin: 0;
            padding: 20px;
            background-color: var(--background-color);
            color: var(--text-color);
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            background-color: #ffffff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        h1 {
            color: var(--primary-color);
            text-align: center;
            margin-bottom: 30px;
        }
        .controls {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }
        .search-container {
            position: relative;
            flex-grow: 1;
            margin-right: 10px;
            display: flex;
            align-items: center;
        }
        .search-container input[type="submit"] {
            margin-left: 10px;
            background-color: var(--primary-color);
            color: white;
            border: none;
            padding: 10px 20px;
            font-size: 16px;
            cursor: pointer;
            border-radius: 4px;
            transition: background-color 0.3s;
        }
        .search-icon {
            position: absolute;
            left: 10px;
            top: 50%;
            transform: translateY(-50%);
            color: #666;
        }
        #searchInput {
            width: 100%;
            padding: 10px 10px 10px 35px;
            border: 1px solid var(--border-color);
            border-radius: 4px;
            font-size: 16px;
        }
        button {
            background-color: var(--primary-color);
            color: white;
            border: none;
            padding: 10px 20px;
            font-size: 16px;
            cursor: pointer;
            border-radius: 4px;
            transition: background-color 0.3s;
        }
        button:hover {
            background-color: #3a7bc8;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background-color: #ffffff;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        }
        th, td {
            border: 1px solid var(--border-color);
            padding: 12px;
            text-align: left;
        }
        th {
            background-color: #f8f9fa;
            font-weight: bold;
            color: var(--primary-color);
        }
        tr:nth-child(even) {
            background-color: #f8f9fa;
        }
        .action-buttons {
            display: flex;
            gap: 10px;
        }
        .edit-btn, .delete-btn {
            padding: 5px 10px;
            font-size: 14px;
        }
        .edit-btn {
            background-color: var(--secondary-color);
        }
        .delete-btn {
            background-color: #e74c3c;
        }
        .modal {
            display: none; /* Hidden by default */
            position: fixed; /* Stay in place */
            z-index: 1; /* Sit on top */
            left: 0;
            top: 0;
            width: 100%; /* Full width */
            height: 100%; /* Full height */
            overflow: auto; /* Enable scroll if needed */
            background-color: rgba(0, 0, 0, 0.5); /* Black w/ opacity */
        }
        .modal-content {
            background-color: #fefefe; /* White background */
            margin: auto; /* Center the modal */
            padding: 20px;
            border: 1px solid #888;
            width: 80%; /* Could be more or less, depending on screen size */
            max-width: 500px; /* Maximum width of the modal */
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            position: relative; /* Required for positioning inside modal */
            top: 50%; /* Move down 50% of the screen */
            transform: translateY(-50%); /* Adjust to center vertically */
        }
        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
        }
        .close:hover,
        .close:focus {
            color: #000;
            text-decoration: none;
            cursor: pointer;
        }
        form {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }
        label {
            font-weight: bold;
            color: var(--primary-color);
        }
        input[type="text"],
        input[type="date"],
        input[type="time"] {
            width: 100%;
            padding: 8px;
            border: 1px solid var(--border-color);
            border-radius: 4px;
            font-size: 16px;
        }
        .add-request-form {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }
        .add-request-form input {
            flex: 1;
            min-width: 120px;
            padding: 8px;
            border: 1px solid var(--border-color);
            border-radius: 4px;
            font-size: 14px;
        }
        .add-request-form button {
            padding: 8px 15px;
            font-size: 14px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Admin Dashboard</h1>
        <div class="controls">
            <form method="POST" class="controls">
                <div class="search-container">
                    <span class="search-icon">🔍</span>
                    <input type="text" id="searchInput" name="searchInput" placeholder="Search requests...">
                    <input type="submit" id="search" name="search" value="Search" class="search-btn">
                </div>
            </form>
            <button id="addRequestBtn">Add new request</button>
        </div>

        <table id="requestsTable">
            <thead>
                <tr>
                    <th>email</th>
                    <th>Name</th>
                    <th>Date</th>
                    <th>Time</th>
                    <th>Nutritionist</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                include 'Connect.php';

                $sql = "SELECT * FROM request";

                if (isset($_POST['search'])) {
                    $require = $_POST['searchInput'] ?? ''; // Use null coalescing operator to handle empty inputs
                    if (!empty($require)) {
                        $sql = "SELECT * FROM request WHERE email LIKE '%" . mysqli_real_escape_string($conn, $require) . "%'";
                    }
                }

                $result = mysqli_query($conn, $sql);

                if (mysqli_num_rows($result) > 0) {
                    while ($row = mysqli_fetch_assoc($result)) {
                        echo "<tr>";
                        echo "<td>" . $row['email'] . "</td>";
                        echo "<td>" . $row['username'] . "</td>";
                        echo "<td>" . $row['Date'] . "</td>";
                        echo "<td>" . $row['Time'] . "</td>";
                        echo "<td>" . $row['Nutritionist'] . "</td>";
                        echo "<td class='action-buttons'>
                                <button class='edit-btn' onclick=\"openRWindow('" . $row['email'] . "', '" . $row['Date'] . "', '" . $row['Time'] . "', 'request')\">Edit</button>
                                <button class='delete-btn' onclick=\"window.location.href='delete.php?action=request&Date=" . $row['Date'] . "&Time=" . $row['Time'] . "'\">Delete</button>
                            </td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='6'>No results found</td></tr>";
                }

                mysqli_close($conn);
                ?>
            </tbody>
        </table>
    </div>

    <div id="addRequestModal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <h2>Add New Request</h2>
            <form id="addRequestForm" method="POST" action="add_db.php">
                <label for="RDate">Request Date:</label>
                <input type="date" id="RDate" name="RDate" required>

                <label for="RTime">Select Time:</label>
                <input type="time" id="RTime" name="RTime" required>

                <label for="nut">Nutritionist:</label>
                <select name="nut" id="nut" required>
                    <option value="James Hunter">James Hunter</option>
                    <option value="Selena Yamada">Selena Yamada</option>
                    <option value="Sarah Belmoris">Sarah Belmoris</option>
                    <option value="Philip Fry">Philip Fry</option>
                </select>

                <button type="submit" id="submitRequest">Submit</button>
                <input type="hidden" id="Id" name="Id" value="R" readonly>
            </form>
        </div>
    </div>

    <script>
        const modal = document.getElementById("addRequestModal");
        const btn = document.getElementById("addRequestBtn");
        const span = document.getElementsByClassName("close")[0];

        // Open the modal
        btn.addEventListener('click', () => {
            modal.style.display = "block";
        });

        // Close the modal when 'x' is clicked
        span.addEventListener('click', () => {
            modal.style.display = "none";
        });

        // Close the modal when user clicks outside of the modal
        window.onclick = function(event) {
            if (event.target === modal) {
                modal.style.display = "none";
            }
        }
    </script>
</body>
</html>
