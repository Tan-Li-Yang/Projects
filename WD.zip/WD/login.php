<!DOCTYPE html>
<html>
    <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
       <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .container{
            background-color: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            width: 400px;
        }

        input[type="text"],input[type = "password"]{
            width: 90%;
            padding: 10px;
            margin: 5px 0 15px 0;
            display: inline-block;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        input[type="submit"] {
            background-color: #ff4081;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-weight: bold;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }

        h1{
            color: green;
        }

       
       </style>
    </head>
    <body>
    <?php

 
$loginErr = "";
session_start();
if($_SERVER['REQUEST_METHOD']=="POST"){
    $userinput=empty($_POST["userinput"])?"":$_POST["userinput"];
$input_password=empty($_POST["pwd"])?"":$_POST["pwd"];

include 'Connect.php';

if(empty($userinput)&& empty($input_password)){
    $loginErr = "Please provide valid username or email and password.";
}
else{
    if(filter_var($userinput,FILTER_VALIDATE_EMAIL)){

        $email = $userinput;
        $sql = "SELECT password FROM users WHERE email = ?";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt,"s",$email);
    }
    
    else{
        $userName = $userinput;
        $sql = "SELECT password FROM users WHERE username=?";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt,"s",$userName);
    }

}

mysqli_stmt_execute($stmt);
mysqli_stmt_store_result($stmt);
if (mysqli_stmt_num_rows($stmt) > 0) {
	
    mysqli_stmt_bind_result($stmt, $hashed_password);
    mysqli_stmt_fetch($stmt);

    if(password_verify($input_password,$hashed_password)){
        $loginErr = "Login success!";
        $_SESSION['userinput'] = $userinput;

        $email = $userinput;
        $sql = "SELECT role FROM users WHERE email = ?";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt,"s",$email);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_bind_result($stmt, $role);
        mysqli_stmt_fetch($stmt);

        if($role === 'admin'){
            header("Location:admin_dashboard.php");
        }else
            header("Location:index.php");
    }
    else {
        // Password is incorrect
       $loginErr= "Invalid password.";
    }

}
else{
    $loginErr = "Invalid username or email.";
}

mysqli_close($conn);
}
?>
        <div class="container">
        <h1>Huan Fitness Pal</h1>
        <form id="login" name="login" method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">
        <label for ="userinput">Username or Email:</label>
        <br>
        <input type="text" id="userinput" name="userinput"  required>
        <br>
        <label for="pwd">Password:</label>
        <br>
        <input type="password" id="pwd" name="pwd" required>
        <br>
        <span class="error"><?php echo $loginErr;?></span>
        <br>
        Doesn't have account yet?<a href="register.php">Click here</a>
        <br>
        Forgot your password?<a href="change_password.php">Click here</a>
        <br>
        <input type="submit" value="Log in" id="register" name="register">
        </div>


        
    </body>
</html>





