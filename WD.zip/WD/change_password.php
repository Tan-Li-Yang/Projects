<?php

$uiErr = $pwdErr = "";
$userinput = $new_password = $confirm_password = $new_hashed_password = "";

include 'Connect.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the form data
    $userinput = $_POST['userinput']; // Could be email or username
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];

    // Ensure new password and confirmation match
    if ($new_password !== $confirm_password) {
        $pwdErr = "New password and confirmation do not match.";
    } else {
        $new_hashed_password = password_hash($new_password, PASSWORD_BCRYPT);

        // Determine if the input is an email or a username
        if (filter_var($userinput, FILTER_VALIDATE_EMAIL)) {
            // If it's an email, check if the email exists in the database
            $sql = "SELECT * FROM users WHERE email = ?";
        } else {
            // Otherwise, check if the username exists in the database
            $sql = "SELECT * FROM users WHERE username = ?";
        }

        // Prepare the SQL statement
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "s", $userinput);

        // Execute the statement
        mysqli_stmt_execute($stmt);
        mysqli_stmt_store_result($stmt);

        // Check if the user exists
        if (mysqli_stmt_num_rows($stmt) == 0) {
            // If no rows are found, display an error message
            $uiErr = "Error: No account found with that username or email.";
        } else {
            // If user exists, update the password
            if (filter_var($userinput, FILTER_VALIDATE_EMAIL)) {
                $sql = "UPDATE users SET password = ? WHERE email = ?";
            } else {
                $sql = "UPDATE users SET password = ? WHERE username = ?";
            }

            // Prepare the update statement
            $stmt = mysqli_prepare($conn, $sql);
            mysqli_stmt_bind_param($stmt, "ss", $new_hashed_password, $userinput);

            // Execute the update statement and check for success
            if (mysqli_stmt_execute($stmt)) {
                $pwdErr = "Password successfully updated!";
                header("Location: login.php");
            } else {
                echo "Error updating password: " . mysqli_error($conn);
            }

            // Close the statement and connection
            mysqli_stmt_close($stmt);
            mysqli_close($conn);
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width-device-width, initial-scale=1.0">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .container {
            background-color: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            width: 400px;
        }
        input[type="text"], input[type="password"] {
            width: 90%;
            padding: 10px;
            margin: 5px 0 15px 0;
            display: inline-block;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-weight: bold;
        }
        input[type="submit"]:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <div class="container">
        <h3>Change Password</h3>
        <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="POST">
            <label for="userinput">Username or Email Address:</label>
            <br>
            <input type="text" name="userinput" required>
            <br>
            <span class="error"><?php echo $uiErr; ?></span>
            <br>
            <label for="new_password">New Password:</label>
            <br>
            <input type="password" name="new_password" required minlength="8">
            <br>
            <label for="confirm_password">Confirm New Password:</label>
            <input type="password" name="confirm_password" required minlength="8">
            <br>
            <span class="error"><?php echo $pwdErr; ?></span>
            <br>
            <input type="submit" name="change_password" value="Change Password">
        </form>
    </div>
</body>
</html>
