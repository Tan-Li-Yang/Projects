<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <style>

        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .container{
            background-color: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            width: 400px;
        }

        input[type="text"],input[type="email"],input[type = "password"],[type="tel"]{
            width: 90%;
            padding: 10px;
            margin: 5px 0 15px 0;
            display: inline-block;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-weight: bold;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }

        h3{
            font:bold;
    color:green;
    font-size: 1.8rem;
    font-weight: 700;
        }


        </style>
    </head>
    <body>
    <?php
$userName = $gender = $email = $phone_no = $bdate = $create_pwd = $confirmed_pwd = $hashed_pwd = $formattedDate = "";
$invalidEmail = $pwdErr = $pwdErr1 = $invalidPhoneNo = $usernameErr = "";
$role = 'user';

if($_SERVER["REQUEST_METHOD"] == "POST"){

    $userName = empty($_POST["username"]) ? "" : $_POST["username"];
    $gender = isset($_POST["gender"]) ? $_POST["gender"] : "";
    $email = $_POST["Email"];
    $phone_no = $_POST["phnumber"];
    $dob = empty($_POST["bdate"]) ? "" : $_POST["bdate"];

    // Email validation
    if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
        $invalidEmail = "Invalid email format.";
    }

    // Password validation
    $create_pwd = $_POST["crpwd"];
    $confirmed_pwd = $_POST["copwd"];
    
    if(strlen($create_pwd) < 8){
        $pwdErr1 = "Password must be at least 8 characters long.";
    }

    if($create_pwd !== $confirmed_pwd){
        $pwdErr = "Passwords do not match.";
    }

    // Phone number validation
    $phone_pattern = "/^\+?(\d{1,3})?\s?(\(?\d{3}\)?)\s?-?\d{3}-?\d{4}$/";
    if(!preg_match($phone_pattern, $phone_no)){
        $invalidPhoneNo = "Invalid phone number format. E.g., +1 123-456-7890";
    }

    // Date formatting
    try {
        $dateObj = new DateTime($dob); // Create a DateTime object
        $formattedDate = $dateObj->format('Y-m-d'); // Format the date
    } catch (Exception $e) {
        echo "Invalid date format.";
        exit;
    }

    // Proceed only if there are no validation errors
    if (empty($invalidEmail) && empty($pwdErr1) && empty($pwdErr) && empty($invalidPhoneNo)) {
        
        // Hash the password for security
        $hashed_pwd = password_hash($create_pwd, PASSWORD_DEFAULT);

        include 'Connect.php';

        // Check if username exists
        $check_sql = "SELECT username FROM users WHERE username = ?";
        $stmt_check = mysqli_prepare($conn, $check_sql);
        mysqli_stmt_bind_param($stmt_check, 's', $userName);
        mysqli_stmt_execute($stmt_check);
        mysqli_stmt_store_result($stmt_check);

        if (mysqli_stmt_num_rows($stmt_check) > 0) {
            $usernameErr = "Username already exists. Please choose another one.";
        } else {
            // Insert into the database
            $sql = "INSERT INTO users (username, gender, email, phonenumber, dob, password, role) VALUES (?, ?, ?, ?, ?, ?, ?)";
            $stmt = mysqli_prepare($conn, $sql);
            mysqli_stmt_bind_param($stmt, 'sssssss', $userName, $gender, $email, $phone_no, $formattedDate, $hashed_pwd, $role);
            
            if (mysqli_stmt_execute($stmt)) {
                echo "New record created successfully";
                header("Location:Dashhboard.php");
                exit();
            } else {
                echo "Error: $sql <br>" . mysqli_error($conn);
            }

            mysqli_stmt_close($stmt);
        }

        mysqli_stmt_close($stmt_check);
        mysqli_close($conn);
    }
}
?>
        <div class="container">

        
        <h3>Huan Fitness Pal Sign Up</h3>
        <form id="signup" name="signup" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <label for ="username">Username</label>
        <br>
        <span class="error"><?php echo $usernameErr?></span>
        <input type="text" id="username" name="username" maxlength="100" placeholder="eg. Anri" required>
        <br>
        <br>
        <label for="gender">Gender</label>
        <br>
        <input type="radio" id="male" name="gender" value="male" checked>
        <label for="male">male</label>
        <input type="radio" id="female" name="gender" value="female" checked>
        <label for="female">female</label>
        <br>
        <br>
        <label for="Email">Email:</label>
        <br>
        <input type="email" id="Email" name="Email" required>
        <br>
        <span class="error"><?php echo $invalidEmail;?></span>
        <br>
        <label for="phnumber">Phone number:</label>
        <br>
        <input type="tel" id="phnumber" name="phnumber" required>
        <br>
        <span class="error"><?php echo $invalidPhoneNo; ?></span>
        <br>
        <label for="bdate">Date of birth</label>
        <input type="date" id="bdate" name="bdate" required>
        <br>
        <label for="crpwd">Create password:</label>
        <br>
        <input type="password" id="crpwd" name="crpwd" required>
        <br>
        <span class="error"><?php echo $pwdErr1; ?></span>
        <br>
        <label for="copwd">Confirm password:</label>
        <br>
        <input type="password" id="copwd" name="copwd" required>
        <br>
        <span class="error"><?php echo $pwdErr; ?></span>
        <br>
        Already have an account？ <a href="login.php">Click here</a>
        <br>
        <input type="submit" value="Sign up" id="register" name="register">

        </form>
        </div>
    </body>
</html>



