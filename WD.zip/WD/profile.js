
document.addEventListener('DOMContentLoaded', function() {
    // Set initial active state for appointment page
    const profileItem = document.getElementById('profileItem');
    profileItem.classList.add('active');

    // Remove active class from all items
    function removeActiveClass() {
        const items = document.querySelectorAll('.nav-item');
        items.forEach(item => item.classList.remove('active'));
    }

    // Handle click on Management dropdown
    const managementItem = document.getElementById('managementItem');
    const dropdownToggle = managementItem.querySelector('.dropdown-toggle');
    dropdownToggle.addEventListener('click', function(e) {
        e.preventDefault();
        e.stopPropagation();
        removeActiveClass();
        managementItem.classList.toggle('active');
    });

    // Close dropdown when clicking outside
    document.addEventListener('click', function(e) {
        if (!managementItem.contains(e.target)) {
            managementItem.classList.remove('active');
        }
    });

    // Prevent dropdown from closing when clicking inside
    managementItem.addEventListener('click', function(e) {
        e.stopPropagation();
    });

    // Handle clicks on dropdown menu items
    const dropdownMenuItems = managementItem.querySelectorAll('.dropdown-menu a');
    dropdownMenuItems.forEach(item => {
        item.addEventListener('click', (e) => {
            removeActiveClass();
            managementItem.classList.add('active');
        });
    });

    // Add hover effect to nav items
    const navItems = document.querySelectorAll('.nav-item');
    navItems.forEach(item => {
        item.addEventListener('mouseenter', () => {
            if (!item.classList.contains('active')) {
                item.style.backgroundColor = 'rgba(255, 255, 255, 0.05)';
            }
        });
        item.addEventListener('mouseleave', () => {
            if (!item.classList.contains('active')) {
                item.style.backgroundColor = '';
            }
        });
    });
});
