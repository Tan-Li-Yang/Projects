<?php
session_start();

if (!isset($_SESSION['userinput'])) {
    header("Location: login.php");
    exit();
}
$email = $_SESSION['userinput'];

include 'Connect.php';

$sql = "SELECT * FROM target WHERE email='$email'";
        $result = mysqli_query($conn, $sql);
        if (mysqli_num_rows($result) > 0) {
            $row = mysqli_fetch_assoc($result);
            $water = $row["water"];
            $weight = $row["weight"];
            $calory = $row["Calory"];
        }
?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="DashhboardStyle.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        input[type=number]::-webkit-inner-spin-button,
        input[type=number]::-webkit-outer-spin-button {
            -webkit-appearance: none;
            margin: 0;
        }
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        .edit_profile-container {
            width: 60%;
            margin: 50px auto;
            background-color: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        input[type="number"], input[type="email"], input[type="password"], input[type="tel"], select {
            width: 90%;
            padding: 10px;
            margin: 5px 0 15px 0;
            display: inline-block;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        input[type="submit"], .change_password-btn {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-weight: bold;
        }
        .change_password-btn a {
            text-decoration: none;
            padding: 10px 20px;
            background-color: #4CAF50;
            color: white;
            border-radius: 4px;
        }
        input[type="submit"]:hover, .change_password-btn:hover {
            background-color: #45a049;
        }

    </style>
</head>
<body>
    <main>
        <nav class="main-menu">
            <br><br><br>
            <ul>
                <li class="nav-item">
                    <a href="Dashhboard.php">
                        <i class="fa fa-house nav-icon"></i>
                        <span class="nav-text">Dashboard</span>
                    </a>
                </li>
                <li class="nav-item dropdown" id="managementItem">
                <b></b>
                <b></b>
                <a href="#" class="dropdown-toggle">
                    <i class="fa fa-user nav-icon"></i>
                    <span class="nav-text">Management</span>
                    <i class="fa fa-chevron-down dropdown-icon"></i>
                </a>
                <ul class="dropdown-menu">
                    <li><a href="weight.php"><i class="fa fa-weight-scale"></i> Weight</a></li>
                    <li><a href="exercise.php"><i class="fa fa-dumbbell"></i> Exercise</a></li>
                    <li><a href="water.php"><i class="fa fa-glass-water"></i> Water Consumption</a></li>
                    <li><a href="calory.php"><i class="fa fa-cal"></i> Calory</a></li>
                    <li><a href="nutritionist.php"><i class="fa fa-nut"></i> Nutritionist</a></li>
                </ul>
            </li>
                <li class="nav-item">
                    <a href="appointment.php">
                        <i class="fa fa-calendar-check nav-icon"></i>
                        <span class="nav-text">Appointment</span>
                    </a>
                </li>
                <li class="nav-item active">
                    <a href="profile.php">
                        <i class="fa fa-calendar-check nav-icon"></i>
                        <span class="nav-text">Profile</span>
                    </a>
                </li>
                <li class="nav-item">
                <b></b>
                <b></b>
                <a href="class_booking.php">
                    <i class="fa fa-calendar-check nav-icon"></i>
                    <span class="nav-text">Fitness classes</span>
                </a>
          </li>
            </ul>
        </nav>

        <div class="edit_profile-container">
            <h2>Edit Profile</h2> <br>
            <form method="POST" action="Override.php">
                <label for="Btarget">Target weight:</label><br>
                <input type="number" name="Btarget" value="<?=$weight?>" placeholder="kg" step="0.01" required min="1"><br><br>

                <label for="Wtarget">Target water consumption (each day):</label><br>
                <input type="number" name="Wtarget" value="<?=$water?>" placeholder="ml" step="0.01" required min="1"><br><br>

                <label for="Ctarget">Target Calory Intake (each day):</label><br>
                <input type="number" name="Ctarget" value="<?=$calory?>" placeholder="kcal" step="0.01" required min="1"><br><br>

                <input type="hidden" id="Id" name="Id" value="T" readonly>
                <input type="submit" value="Save Target" name="savetarget">
            </form>
        </div>
    </main>
</body>
</html>

<script src="profile.js" defer></script>


