<?php
session_start();

$userName = $gender = $email = $ph_no = $bdate = "";

if (!isset($_SESSION['userinput'])) {
    header("Location: login.php");
    exit();
}

include 'Connect.php';

$userinput = $_SESSION['userinput'];

if (filter_var($userinput, FILTER_VALIDATE_EMAIL)) {
    $email = $userinput;
    $sql = "SELECT * FROM users WHERE email = ?; ";
} else {
    $userName = $userinput;
    $sql = "SELECT * FROM users WHERE username = ?; ";
}

$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "s", $userinput);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if ($row = mysqli_fetch_assoc($result)) {
    $userName = $row["username"];
    $gender = $row["gender"];
    $email = $row["email"];
    $ph_no = $row["phonenumber"];
    $bdate = $row["dob"];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Profile</title>
    <link rel="stylesheet" href="DashhboardStyle.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        .profile-container {
            width: 60%;
            margin: 50px auto;
            background-color: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }

        .profile-picture {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            object-fit: cover;
            margin-bottom: 20px;
        }

        .profile-details {
            text-align: center;
        }

        .profile-details h1 {
            margin-bottom: 10px;
        }

        .edit-profile {
            margin-top: 20px;
            text-align: center;
        }

        .edit-profile a {
            text-decoration: none;
            padding: 10px 20px;
            background-color: #4CAF50;
            color: white;
            border-radius: 5px;
        }
    </style>
</head>
<body>
<header>
        <div class="logo">HuanFitnessPal</div>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <?php
                if (!isset($_SESSION['userinput'])) {
                }else{
                    echo '<li><a href="dashhboard.php">Data</a></li>';
                }
                ?>
                <li><a href="aboutus.php">About US</a></li>
                
            </ul>
        </nav>
        <div class="cta-buttons">
            <?php
                if (!isset($_SESSION['userinput'])) {
                    echo '<button class="cta-button"><a href="register.php">Register</a></button>';
                    echo '<button class="cta-button"><a href="login.php">Login</a></button>';
                }else{
                    echo '<button class="cta-button"><a href="logout.php">Sign Out</a></button>';
                }
            ?>
        </div>
    </header>
  
  
    <main>
      <nav class="main-menu">
        <br><br><br>
        <ul>
            <li class="nav-item">
                <b></b>
                <b></b>
                <a href="Dashhboard.php">
                    <i class="fa fa-house nav-icon"></i>
                    <span class="nav-text">Dashboard</span>
                </a>
            </li>
            <li class="nav-item dropdown" id="managementItem">
                <b></b>
                <b></b>
                <a href="#" class="dropdown-toggle">
                  <i class="fa fa-user nav-icon"></i>
                  <span class="nav-text">Management</span>
                  <i class="fa fa-chevron-down dropdown-icon"></i>
              </a>
              <ul class="dropdown-menu">
                  <li><a href="weight.php"><i class="fa fa-weight-scale"></i> Weight</a></li>
                  <li><a href="exercise.php"><i class="fa fa-dumbbell"></i> Exercise</a></li>
                  <li><a href="water.php"><i class="fa fa-glass-water"></i> Water Consumption</a></li>
                  <li><a href="calory.php"><i class="fa fa-cal"></i> Calory</a></li>
                  <li><a href="nutritionist.php"><i class="fa fa-nut"></i> Nutritionist</a></li>
              </ul>
            </li>
            <li class="nav-item">
                <b></b>
                <b></b>
                <a href="appointment.php" >
                    <i class="fa fa-calendar-check nav-icon"></i>
                    <span class="nav-text">Appointment</span>
                </a>
            </li>
            <li class="nav-item active" id="profileItem">
                <b></b>
                <b></b>
                <a href="profile.php">
                    <i class="fa fa-calendar-check nav-icon"></i>
                    <span class="nav-text">Profile</span>
                </a>
            </li>
            <li class="nav-item">
                <b></b>
                <b></b>
                <a href="class_booking.php">
                    <i class="fa fa-calendar-check nav-icon"></i>
                    <span class="nav-text">Fitness classes</span>
                </a>
            </li>
        </ul>
    </nav>

    <div class="profile-container">
        <div class="profile-details">
            <!-- Display profile picture -->
            <img src="res/defaultprofilepicture1.jpg" class="profile-picture">
        
            <!-- Display user details -->
            <h1><?php echo $userName; ?></h1>
            <p>Gender: <?php echo $gender; ?></p>
            <p>Email: <?php echo $email; ?></p>
            <p>Phone Number: <?php echo $ph_no; ?></p>
            <p>Date of birth: <?php echo $bdate; ?></p>
        </div>

        <!-- Edit Profile Button -->
        <div class="edit-profile">
            <a href="edit_profile.php">Edit Profile</a>
            <a href="edit_target.php">Edit Target</a>
        </div>
    </div>
</main>
</body>
</html>

<script src="profile.js" defer></script>


