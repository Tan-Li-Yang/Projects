<?php
session_start();
if (!isset($_SESSION['userinput'])) {
    header("Location: login.php");
    exit();
}
include 'Connect.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calory Intake Tracker</title>
    <link rel="stylesheet" href="data_css.css">
    <script src="https://kit.fontawesome.com/your-fontawesome-kit.js" crossorigin="anonymous"></script>
</head>
<body>
<header>
        <div class="logo">HuanFitnessPal</div>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <?php
                if (!isset($_SESSION['userinput'])) {
                }else{
                    echo '<li><a href="dashhboard.php">Data</a></li>';
                }
                ?>
                <li><a href="aboutus.php">About US</a></li>
                
            </ul>
        </nav>
        <div class="cta-buttons">
            <?php
                if (!isset($_SESSION['userinput'])) {
                    echo '<button class="cta-button"><a href="register.php">Register</a></button>';
                    echo '<button class="cta-button"><a href="login.php">Login</a></button>';
                }else{
                    echo '<button class="cta-button"><a href="logout.php">Sign Out</a></button>';
                }
            ?>
        </div>
    </header>
  
  
    <main>
      <nav class="main-menu">
        <br><br><br>
        <ul>
            <li class="nav-item">
                <b></b>
                <b></b>
                <a href="Dashhboard.php">
                    <i class="fa fa-house nav-icon"></i>
                    <span class="nav-text">Dashboard</span>
                </a>
            </li>
            <li class="nav-item active dropdown">
                <b></b>
                <b></b>
                <a href="#" class="dropdown-toggle">
                  <i class="fa fa-user nav-icon"></i>
                  <span class="nav-text">Management</span>
                  <i class="fa fa-chevron-down dropdown-icon"></i>
              </a>
              <ul class="dropdown-menu">
                  <li><a href="weight.php"><i class="fa fa-weight-scale"></i> Weight</a></li>
                  <li><a href="exercise.php"><i class="fa fa-dumbbell"></i> Exercise</a></li>
                  <li><a href="water.php"><i class="fa fa-glass-water"></i> Water Consumption</a></li>
                  <li><a href="calory.php"><i class="fa fa-cal"></i> Calory</a></li>
                  <li><a href="nutritionist.php"><i class="fa fa-nut"></i> Nutritionist</a></li>
              </ul>
            </li>
            <li class="nav-item">
                <b></b>
                <b></b>
                <a href="appointment.php">
                    <i class="fa fa-calendar-check nav-icon"></i>
                    <span class="nav-text">Appointment</span>
                </a>
            </li>
            <li class="nav-item">
                <b></b>
                <b></b>
                <a href="profile.php">
                    <i class="fa fa-calendar-check nav-icon"></i>
                    <span class="nav-text">Profile</span>
                </a>
            </li>
            <li class="nav-item">
                <b></b>
                <b></b>
                <a href="class_booking.php">
                    <i class="fa fa-calendar-check nav-icon"></i>
                    <span class="nav-text">Fitness classes</span>
                </a>
            </li>
        </ul>
    </nav>
        <div class="container">
            <h1>Calory Intake Tracker</h1>
            <button class="addB" onclick="addCWindow('calory')">Add Calory Intake</button>
            <div class="search-container">
                <input type="date" id="searchInput">
                <button onclick="searchData()">Search</button>
                <input type="text" id="searchInput2" placeholder="Enter Food">
                <button onclick="searchFoodData()">Search</button>
                <button class="clear-btn"onclick="location.reload()">Clear</button>
            </div>
            <table id="dataTable">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Time</th>
                        <th>Food</th>
                        <th>Calories</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $email = $_SESSION['userinput'];
                    $sql = "SELECT * FROM calory WHERE email='$email' ORDER BY Date DESC, Time DESC";
                    $calory_check = "SELECT Calory FROM calory WHERE date= CURDATE()";
                    $target_cal = "SELECT Calory FROM target WHERE email='$email'";
                    $result = $conn->query($sql);
                    $result2 = $conn->query($calory_check);
                    $result3 = $conn->query($target_cal);

                    $ate_cal = 0;

                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            echo "<tr>";
                            echo "<td>" . $row['Date'] . "</td>";
                            echo "<td>" . $row['Time'] . "</td>";
                            echo "<td>" . $row['Food'] . "</td>";
                            echo "<td>" . $row['Calory'] . "</td>";
                            echo "<td class='action-buttons'>
                                    <button class='edit-btn' onclick=\"openCWindow('" . $row['email'] . "', '" . $row['Date'] . "', '" . $row['Time'] . "', 'calory')\">Edit</button>
                                    <button class='delete-btn' onclick=\"window.location.href='delete.php?action=calory&Date=" . $row['Date'] . "&Time=" . $row['Time'] . "'\">Delete</button>
                                  </td>";
                            echo "</tr>";
                        }
                    }

                    while ($row2 = $result2->fetch_assoc()) {
                        $ate_cal += $row2['Calory'];
                    }
    
                    // Fetch target calories
                    $target_cal_value = 0;
                    if ($result3->num_rows > 0) {
                        $target_row = $result3->fetch_assoc();
                        $target_cal_value = $target_row['Calory'];
                    }
    
                    if ($ate_cal > $target_cal_value) {
                        echo "<script type='text/javascript'> alert('You have exceeded your target calorie intake for the day.'); </script>"; 
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </main>
    <script src="data.js" defer></script>
</body>
</html>