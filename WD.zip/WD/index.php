<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fitness Point - Get Fit To Happy</title>
    <link rel="stylesheet" href="homepagestyle.css">
	<style type="text/css">
	.auto-style1 {
		text-align: right;
	}
	</style>
</head>
<body>
<header>
        <div class="logo">HuanFitnessPal</div>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <?php
                if (!isset($_SESSION['userinput'])) {
                }else{
                    echo '<li><a href="dashhboard.php">Data</a></li>';
                }
                ?>
                <li><a href="aboutus.php">About US</a></li>
                
            </ul>
        </nav>
        <div class="cta-buttons">
            <?php
                if (!isset($_SESSION['userinput'])) {
                    echo '<button class="cta-button"><a href="register.php">Register</a></button>';
                    echo '<button class="cta-button"><a href="login.php">Login</a></button>';
                }else{
                    echo '<button class="cta-button"><a href="logout.php">Sign Out</a></button>';
                }
            ?>
        </div>
    </header>

    <main>
        <section id="hero">
            <div class="hero-content">
                <h1>DON'T STOP TILL YOUR SUCCESS!</h1>
                <h2>GET FIT TO HAPPY</h2>
                <p>Start your fitness journey today and transform your life with our expert guidance and support.</p>
                <button class="cta-button"><a href="dashhboard.php">Explore More</a></button>
            </div>
            <div class="hero-image">
                <img src="res/pic1.png">
            </div>
        </section>

        <section id="change">
            <div class="change-image">
                <img src="res/pic2.png" >
            </div>
            <div class="change-content">
                <h2>Ready to make a change?</h2>
                <p>Our fitness programs are designed to help you achieve your goals, whether you're looking to lose weight, build muscle, or improve your overall health.</p>
                <button class="cta-button"><a href="Dashhboard.php">Get Started</a></button>
            </div>
        </section>

        <section id="services">
            <h2>Services We Provide</h2>
            <div class="services-grid">
                <div class="service-item">
                    <h3>Managing Fitness Data</h3>
                    <p>Personalized workout plans tailored to your fitness level and goals.</p>
                </div>
                <div class="service-item">
                    <h3>Maintaining a Healthy Lifestyle</h3>
                    <p>Find balance and inner peace with our expert-led yoga classes.</p>
                </div>
                <div class="service-item">
                    <h3>Excercise Routines</h3>
                    <p>Improve flexibility, strength, and coordination with gymnastics training.</p>
                </div>
                <div class="service-item">
                    <h3>Personalized dietary</h3>
                    <p>Learn self-defense and discipline through our karate programs.</p>
                </div>
            </div>
        </section>

        <section id="about">
            <div class="about-image">
                <img src="res/pic3.jpg">
            </div>
            <div class="about-content">
                <h2>It's About Who You Can Become</h2>
                <p>Our expert trainers are dedicated to helping you unlock your full potential and become the best version of yourself.</p>
            </div>
        </section>

        <section id="trainers">
            <h2>Having Your Own Coach And Mentor</h2>
            <div class="trainer-grid">
                <div class="trainer-item">
                    <img src="res/coach.jpg">
                    <h3>Emma Lili</h3>
                </div>
                <div class="trainer-item">
                    <img src="res/coach2.jpg">
                    <h3>Dominic Snyder</h3>
                </div>
                <div class="trainer-item">
                    <img src="res/caoch3.jpg">
                    <h3>Brenda Pierce</h3>
                </div>
            </div>
        </section>

        <section id="cta">
            <h2>THE BEST TRAINERS OUT THERE</h2>
            <p>Ask for a trainer. Join us.</p>
            <button class="cta-button"><a href="register.php">Register Now</a></button>
        </section>
    </main>

    <footer>
        <div class="footer-content">
            <div class="footer-logo">
                <h2>FITNESS POINT</h2>
            </div>
            <div class="footer-links">
                <h3>Quick Links</h3>
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="dashhboard.php">Data</a></li>
                    <li><a href="aboutus.php">About US</a></li>
                </ul>
            </div>
            <div class="footer-contact">
                <h3>Contact</h3>
                <p>123 Fitness Street, Gym City, 12345</p>
                <p>Phone: (123) 456-7890</p>
                <p>Email: info@fitnesspoint.com</p>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; 2023 Fitness Point. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>