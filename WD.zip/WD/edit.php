<?php
// Get the action parameter from the URL
$action = isset($_GET['action']) ? $_GET['action'] : '';
$Date = isset($_GET['Date']) ? $_GET['Date'] : '';
$time = isset($_GET['Time']) ? $_GET['Time'] : '';
$type = isset($_GET['Type']) ? $_GET['Type'] : '';

// Connect to the database
include 'Connect.php';

// Initialize variables
$Weight = $Stime = $Etime = $Calory = $amount = $nut = $food = '';

// Switch based on action
switch ($action) {
    case 'bodyweight':
        $sql = "SELECT * FROM weight WHERE Date='$Date'";
        $result = mysqli_query($conn, $sql);
        if (mysqli_num_rows($result) > 0) {
            $row = mysqli_fetch_assoc($result);
            $Weight = $row["Weight"];
        }
        break;

    case 'exercise':
        $sql = "SELECT * FROM exercise WHERE Date='$Date' AND Type='$type'";
        $result = mysqli_query($conn, $sql);
        if (mysqli_num_rows($result) > 0) {
            $row = mysqli_fetch_assoc($result);
            $Stime = $row["Start"];
            $Etime = $row["End"];
            $Calory = $row["Calory"];
        }
        break;

    case 'waterconsumption':
        $sql = "SELECT * FROM water WHERE Time='$time'";
        $result = mysqli_query($conn, $sql);
        if (mysqli_num_rows($result) > 0) {
            $row = mysqli_fetch_assoc($result);
            $amount = $row["Amount"];
        }
        break;

    case 'calory':
        $sql = "SELECT * FROM calory WHERE Time='$time'";
        $result = mysqli_query($conn, $sql);
        if (mysqli_num_rows($result) > 0) {
            $row = mysqli_fetch_assoc($result);
            $food = $row["Food"];
            $calory = $row["Calory"];
        }
        break;

    case 'request':
        $sql = "SELECT * FROM request WHERE Date ='$Date'";
        $result = mysqli_query($conn, $sql);
        if (mysqli_num_rows($result) > 0) {
            $row = mysqli_fetch_assoc($result);
            $time = $row["Time"];
            $nut = $row["Nutritionist"];
        }
        break;

    default:
        echo "<p>Please select a form from the navigation.</p>";
        break;
}

mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <script src="data.js" defer></script>
    <style>
        .modal {
            display: block; /* Ensure the modal is displayed */
            position: fixed;
            z-index: 1; /* Sit on top */
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: hidden; /* No scrollbars */
            background-color: rgba(0, 0, 0, 0.4);
        }
        .modal-content {
            background-color: #fefefe;
            margin: auto;
            padding: 20px;
            border: 1px solid #888;
            width: 100%;
            max-width: 500px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        input[type=number]::-webkit-inner-spin-button,
        input[type=number]::-webkit-outer-spin-button {
            -webkit-appearance: none; /* Safari and Chrome */
            margin: 0; /* Reset margin */
        }
    </style>
</head>

<body>
<main>
    <div class="modal">
        <div class="modal-content">
            <?php
            switch ($action) {
                case 'bodyweight':
                    ?>
                    <form id="BWentry" name="BWentry" action="Override.php" method="POST">
                        <label for="Edate">Entry Date</label><br>
                        <input type="date" id="Edate" name="Edate" value="<?=$Date?>" min="2022-12-31" max="<?php echo date("Y-m-d"); ?>"><br><br>

                        <label for="weight">Enter Weight:</label>
                        <input type="number" id="weight" name="weight" placeholder="kg" value="<?=$Weight?>" step="0.01" required min="1"><br><br>

                        <input type="hidden" id="Id" name="Id" value="W" readonly>
                        <input type="hidden" id="Odate" name="Odate" value="<?=$Date?>">
                        <input type="submit" value="Add" id="add" name="add">
                    </form>
                    <?php
                    break;

                case 'exercise':
                    ?>
                    <form id="ERentry" name="ERentry" action="Override.php" method="POST">
                        <label for="Edate">Entry Date</label><br>
                        <input type="date" id="Edate" name="Edate" value="<?=$Date?>" min="2022-12-31" max="<?php echo date("Y-m-d"); ?>"><br><br>

                        <label for="type">Type of exercise:</label>
                        <input type="text" id="type" name="type" value="<?=$type?>" required><br><br>

                        <label for="stime">Starting Time:</label>
                        <input type="time" id="stime" name="stime" value="<?=$Stime?>" required onchange="updateFinishTimeMin()"><br><br>

                        <label for="etime">Finish Time:</label>
                        <input type="time" id="etime" name="etime" value="<?=$Etime?>" required><br><br>

                        <label for="calory">Enter Calories burned:</label>
                        <input type="number" id="calory" name="calory" placeholder="kcal" value="<?=$Calory?>" step="0.01" required min="1"><br><br>

                        <input type="hidden" id="Id" name="Id" value="E" readonly>
                        <input type="hidden" id="Odate" name="Odate" value="<?=$Date?>">
                        <input type="hidden" id="Otype" name="Otype" value="<?=$type?>">
                        <input type="hidden" id="Ostime" name="Ostime" value="<?=$Stime?>">
                        <input type="submit" value="Add" id="add" name="add">
                    </form>
                    <?php
                    break;

                case 'waterconsumption':
                    ?>
                    <form id="WCentry" name="WCentry" action="Override.php" method="POST">
                        <label for="Edate">Entry Date</label><br>
                        <input type="date" id="Edate" name="Edate" value="<?=$Date?>" min="2022-12-31" max="<?php echo date("Y-m-d"); ?>"><br><br>

                        <label for="time">Select Time:</label>
                        <input type="time" id="time" name="time" value="<?=$time?>" required><br><br>

                        <label for="amount">Enter Amount:</label>
                        <input type="number" id="amount" name="amount" placeholder="ml" value="<?=$amount?>" step="0.01" required min="1"><br><br>

                        <input type="hidden" id="Id" name="Id" value="WC" readonly>
                        <input type="hidden" id="Odate" name="Odate" value="<?=$Date?>">
                        <input type="submit" value="Add" id="add" name="add">
                    </form>
                    <?php
                    break;

                case 'calory': 
                    ?>
                        <form id="Centry" name="Centry" action="Override.php" method="POST">
                            <label for="Edate">Entry Date</label><br>
                            <input type="date" id="Edate" name="Edate" value="<?=$Date?>"
                                        min="2022-12-31" max="<?php echo date("Y-m-d")?>"><br><br>

                            <label for="time">Select Time:</label>
                            <input type="time" id="time" name="time" value="<?=$time?>" required><br><br>

                            <label for="food">Enter Food:</label>
                            <input type="text" id="food" name="food" value="<?=$food?>" required><br><br>

                            <label for="calory">Enter Calory: </label>
                            <input type="number" id="calory" name="calory" placeholder="kcal" step="0.01" value="<?=$calory?>" required min=1><br><br>

                            <input type="hidden" id="Id" name="Id" value="C" readonly><br>
                            <input type="hidden" id="Odate" name="Odate" value="<?=$Date?>">
                            <input type="hidden" id="Otime" name="Otime" value="<?=$time?>">
                            <input type="submit" value="Add" id="add" name="add">
                        </form>
                    <?php 
                    break;

                case 'request':
                    ?>
                    <form id="UserR" name="UserR" action="Override.php" method="POST">
                        <label for="Rdate">Request Date</label><br>
                        <input type="date" id="Rdate" name="Rdate" value="<?=$Date?>" min="<?php echo date("Y-m-d"); ?>" max="2024-12-31"><br><br>

                        <label for="Rtime">Select Time:</label>
                        <select id="Rtime" name="Rtime" required>
                            <option value="09:00:00" <?= $time == "09:00:00" ? 'selected' : '' ?>>09.00 a.m.</option>
                            <option value="10:30:00" <?= $time == "10:30:00" ? 'selected' : '' ?>>10.30 a.m.</option>
                            <option value="12:00:00" <?= $time == "12:00:00" ? 'selected' : '' ?>>12.00 p.m.</option>
                            <option value="13:30:00" <?= $time == "13:30:00" ? 'selected' : '' ?>>01.30 p.m.</option>
                            <option value="15:00:00" <?= $time == "15:00:00" ? 'selected' : '' ?>>03.00 p.m.</option>
                            <option value="16:30:00" <?= $time == "16:30:00" ? 'selected' : '' ?>>04.30 p.m.</option>
                            <option value="18:00:00" <?= $time == "18:00:00" ? 'selected' : '' ?>>06.00 p.m.</option>
                        </select> <br><br>

                        <label for="nut">Nutritionist:</label>
                        <select name="nut" id="nut" required>
                            <option value="James Hunter" <?= $nut == "James Hunter" ? 'selected' : '' ?>>James Hunter</option>
                            <option value="Selena Yamada" <?= $nut == "Selena Yamada" ? 'selected' : '' ?>>Selena Yamada</option>
                            <option value="Sarah Belmoris" <?= $nut == "Sarah Belmoris" ? 'selected' : '' ?>>Sarah Belmoris</option>
                            <option value="Philip Fry" <?= $nut == "Philip Fry" ? 'selected' : '' ?>>Philip Fry</option>
                        </select><br><br>

                        <input type="hidden" id="Id" name="Id" value="R" readonly>
                        <input type="hidden" id="Odate" name="Odate" value="<?=$Date?>">
                        <input type="submit" value="Add" id="add" name="add">
                    </form>
                    <?php
                    break;

                default:
                    echo "<p>Please select a form from the navigation.</p>";
                    break;
            }
            ?>
        </div>
    </div>
</main>
</body>
</html>
