document.addEventListener('DOMContentLoaded', () => {
    const wrap = document.querySelector('.wrap');
    const members = document.querySelectorAll('.member');
    const memberBackButtons = document.querySelectorAll('.member-back, .restart');
    const dateBackButtons = document.querySelectorAll('.date-back');
    const confirmButtons = document.querySelectorAll('.confirm-appointment');

    let currentDate = new Date();
    let selectedDate = null;
    let selectedTime = null;
    let nutritionistName = null;  // Track the selected nutritionist's name

    // Set initial active state for appointment page
    const appointmentItem = document.getElementById('appointmentItem');
    appointmentItem.classList.add('active');

    // Remove active class from all items
    function removeActiveClass() {
        const items = document.querySelectorAll('.nav-item');
        items.forEach(item => item.classList.remove('active'));
    }

    

    // Handle click on Management dropdown
    const managementItem = document.getElementById('managementItem');
    const dropdownToggle = managementItem.querySelector('.dropdown-toggle');
    dropdownToggle.addEventListener('click', function(e) {
        e.preventDefault();
        e.stopPropagation();
        removeActiveClass();
        managementItem.classList.toggle('active');
    });

    // Close dropdown when clicking outside
    document.addEventListener('click', function(e) {
        if (!managementItem.contains(e.target)) {
            managementItem.classList.remove('active');
        }
    });

    // Prevent dropdown from closing when clicking inside
    managementItem.addEventListener('click', function(e) {
        e.stopPropagation();
    });

    // Handle clicks on dropdown menu items
    const dropdownMenuItems = managementItem.querySelectorAll('.dropdown-menu a');
    dropdownMenuItems.forEach(item => {
        item.addEventListener('click', (e) => {
            removeActiveClass();
            managementItem.classList.add('active');
        });
    });

    // Add hover effect to nav items
    const navItems = document.querySelectorAll('.nav-item');
    navItems.forEach(item => {
        item.addEventListener('mouseenter', () => {
            if (!item.classList.contains('active')) {
                item.style.backgroundColor = 'rgba(255, 255, 255, 0.05)';
            }
        });
        item.addEventListener('mouseleave', () => {
            if (!item.classList.contains('active')) {
                item.style.backgroundColor = '';
            }
        });
    });

    members.forEach(member => {
        member.addEventListener('click', function(e) {
            if (!this.classList.contains('selected')) {
                this.classList.add('selected');
                wrap.classList.add('member-selected');

                // Check if the nutritionist-name element exists and get the name
                const nameElement = this.querySelector('.name');
                if (nameElement) {
                    nutritionistName = nameElement.textContent.trim(); // Store the nutritionist's name
                } else {
                    console.error('Nutritionist name element not found for this member.');
                    nutritionistName = 'Unknown Nutritionist'; // Fallback to avoid errors
                }

                updateCalendar(this.querySelector('.calendar'));
            }
            e.preventDefault();
            e.stopPropagation();
        });
    });

    memberBackButtons.forEach(btn => {
        btn.addEventListener('click', function(e) {
            members.forEach(member => member.classList.remove('selected'));
            wrap.classList.remove('member-selected', 'date-selected', 'booking-complete');
            e.preventDefault();
            e.stopPropagation();
        });
    });

    dateBackButtons.forEach(btn => {
        btn.addEventListener('click', function(e) {
            wrap.classList.remove('date-selected');
            document.querySelectorAll('.calendar-day').forEach(el => el.classList.remove('selected'));
            e.preventDefault();
            e.stopPropagation();
        });
    });

    confirmButtons.forEach(btn => {
        btn.addEventListener('click', function(e) {
            // Format the selected date to YYYY-MM-DD
            const formattedDate = formatDate(selectedDate);
    
            // Save the selected date and time in session storage (to pass between page reloads)
            sessionStorage.setItem('selectedDate', formattedDate);
            sessionStorage.setItem('selectedTime', selectedTime);
            sessionStorage.setItem('nutritionistName', nutritionistName);

    
            // Redirect to the "request" form by appending the action parameter
            window.location.href = 'add.php?action=request';

            e.preventDefault();
            e.stopPropagation();
        });
    });

    function updateCalendar(calendarElement) {
        const calendarDays = calendarElement.querySelector('.calendar-days');
        const currentMonthYear = calendarElement.querySelector('.current-month-year');
        const prevMonthBtn = calendarElement.querySelector('.prev-month');
        const nextMonthBtn = calendarElement.querySelector('.next-month');

        function renderCalendar() {
            const year = currentDate.getFullYear();
            const month = currentDate.getMonth();
            const firstDay = new Date(year, month, 1);
            const lastDay = new Date(year, month + 1, 0);
            const daysInMonth = lastDay.getDate();
            const startingDay = firstDay.getDay();

            currentMonthYear.textContent = `${currentDate.toLocaleString('default', { month: 'long' })} ${year}`;

            let calendarHTML = '';
            for (let i = 0; i < startingDay; i++) {
                calendarHTML += '<div class="calendar-day"></div>';
            }

            for (let i = 1; i <= daysInMonth; i++) {
                const date = new Date(year, month, i);
                const isToday = date.toDateString() === new Date().toDateString();
                const isPast = date < new Date(new Date().setHours(0, 0, 0, 0));
                const classes = `calendar-day${isToday ? ' today' : ''}${isPast ? ' disabled' : ''}`;
                calendarHTML += `<div class="${classes}" data-date="${date.toISOString()}">${i}</div>`;
            }

            calendarDays.innerHTML = calendarHTML;
            addCalendarListeners(calendarElement);
        }

        prevMonthBtn.addEventListener('click', () => {
            currentDate.setMonth(currentDate.getMonth() - 1);
            renderCalendar();
        });

        nextMonthBtn.addEventListener('click', () => {
            currentDate.setMonth(currentDate.getMonth() + 1);
            renderCalendar();
        });

        renderCalendar();
    }

    function addCalendarListeners(calendarElement) {
        const days = calendarElement.querySelectorAll('.calendar-day:not(.disabled)');
        days.forEach(day => {
            day.addEventListener('click', function() {
                days.forEach(d => d.classList.remove('selected'));
                this.classList.add('selected');
                selectedDate = this.dataset.date; // Store selected date in ISO format
                addSlots(calendarElement.closest('.member'));
                wrap.classList.add('date-selected');

                // Update the confirmation message with the selected date
                updateConfirmationMessage(calendarElement.closest('.member'));
            });
        });
    }

    function addSlots(memberElement) {
        const slotsContainer = memberElement.querySelector('.slots');
        const selectedDate = memberElement.querySelector('.calendar-day.selected').dataset.date;
        const date = new Date(selectedDate);
        const dayOfWeek = date.getDay();

        // Generate 5 time slots
        const slots = [];
        let startTime = 9; // Start at 9 AM
        for (let i = 0; i < 7; i++) {
            const hour = startTime + Math.floor(i * 1.5);
            const minute = (i * 1.5 % 1) * 60;
            slots.push(`${hour.toString().padStart(2, '0')}:${minute.toString().padStart(2, '0')}`);
        }

        let slotsHTML = '';
        slots.forEach(slot => {
            slotsHTML += `<li>${slot}</li>`;
        });

        slotsContainer.innerHTML = slotsHTML;
        invokeSlotsListener(slotsContainer, memberElement);
    }

    function invokeSlotsListener(slotsContainer, memberElement) {
        const slotItems = slotsContainer.querySelectorAll('li');
        slotItems.forEach(slot => {
            slot.addEventListener('click', function() {
                slotItems.forEach(s => s.classList.remove('selected'));
                this.classList.add('selected');
                selectedTime = this.textContent; // Store selected time
                wrap.classList.add('slot-selected');

                // Update the confirmation message with the selected time
                updateConfirmationMessage(memberElement);
            });
        });
    }

    function updateConfirmationMessage(memberElement) {
        const confirmMessage = memberElement.querySelector('.confirm-message');
        const nutritionistName = memberElement.querySelector('.name').textContent.trim();
        const formattedDate = selectedDate ? formatDate(selectedDate) : 'Not selected';
        const formattedTime = selectedTime || 'Not selected';

        confirmMessage.innerHTML = `Booking Complete!<br>
            Nutritionist: ${nutritionistName}<br>
            Date: ${formattedDate}<br>
            Time: ${formattedTime}<br>
            <span class="restart">Book Again?</span>`;
    }

    // Helper function to format date as YYYY-MM-DD
    function formatDate(isoDateString) {
        const date = new Date(isoDateString);
        const year = date.getFullYear();
        const month = (date.getMonth() + 1).toString().padStart(2, '0'); // Months are 0-indexed
        const day = date.getDate().toString().padStart(2, '0');
        return `${year}-${month}-${day}`;
    }

    // Helper function to format date as YYYY-MM-DD
    function formatDate(isoDateString) {
        const date = new Date(isoDateString);
        const year = date.getFullYear();
        const month = (date.getMonth() + 1).toString().padStart(2, '0');
        const day = date.getDate().toString().padStart(2, '0');
        return `${year}-${month}-${day}`;
    }
});

    fetchDashboardData();
