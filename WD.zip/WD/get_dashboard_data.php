<?php
header("Content-Type: application/json");

include 'Connect.php';
session_start();  // Start the session to access session variables
$email = $_SESSION['userinput'];

$response = [];

// Fetch exercise records with prepared statements
$exerciseQuery = $conn->prepare("SELECT Date, Type, Calory FROM exercise WHERE email = ? ORDER BY Date DESC LIMIT 4");
$exerciseQuery->bind_param("s", $email);
$exerciseQuery->execute();
$exerciseResult = $exerciseQuery->get_result();
$response['exerciseRecords'] = [];
while ($row = $exerciseResult->fetch_assoc()) {
    $response['exerciseRecords'][] = $row;
}

// Fetch appointment info with email constraint
$requestQuery = $conn->prepare("SELECT Date, Time, Nutritionist FROM request WHERE email = ? ORDER BY Date DESC LIMIT 1");
$requestQuery->bind_param("s", $email);
$requestQuery->execute();
$requestResult = $requestQuery->get_result();
$response['appointment'] = $requestResult->fetch_assoc();

// Fetch water consumption with email constraint
$waterQuery = $conn->prepare("SELECT Amount FROM water WHERE Date = CURDATE() AND email = ?");
$waterQuery->bind_param("s", $email);
$waterQuery->execute();
$waterResult = $waterQuery->get_result();
$waterData = $waterResult->fetch_assoc();
$response['waterConsumption'] = floatval($waterData['Amount'] ?? 0);

// Fetch calories with email constraint
$caloriesQuery = $conn->prepare("SELECT SUM(Calory) as TotalCalories FROM calory WHERE Date = CURDATE() AND email = ?");
$caloriesQuery->bind_param("s", $email);
$caloriesQuery->execute();
$caloriesResult = $caloriesQuery->get_result();
$caloriesData = $caloriesResult->fetch_assoc();
$response['caloriesBurned'] = floatval($caloriesData['TotalCalories'] ?? 0);


// Fetch latest weight with email constraint
$weightQuery = $conn->prepare("SELECT Weight FROM weight WHERE email = ? ORDER BY Date DESC LIMIT 1");
$weightQuery->bind_param("s", $email);
$weightQuery->execute();
$weightResult = $weightQuery->get_result();
$weightData = $weightResult->fetch_assoc();
$response['latestWeight'] = $weightData['Weight'] ?? 0;

// Fetch calorie target
$targetQuery = $conn->prepare("SELECT Calory FROM target WHERE email = ?");
$targetQuery->bind_param("s", $email);
$targetQuery->execute();
$targetResult = $targetQuery->get_result();
$targetData = $targetResult->fetch_assoc();
$response['calorieTarget'] = floatval($targetData['Calory'] ?? 0);

$conn->close();

echo json_encode($response);
