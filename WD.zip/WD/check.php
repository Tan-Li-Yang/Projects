<?php
session_start(); // Start the session
include 'Connect.php';

if (isset($_POST['date']) && isset($_POST['time']) && isset($_POST['nutritionist'])) {
    $date = mysqli_real_escape_string($conn, $_POST['date']);
    $time = mysqli_real_escape_string($conn, $_POST['time']);
    $nutritionist = mysqli_real_escape_string($conn, $_POST['nutritionist']);

    $sql = "SELECT * FROM request WHERE Date = '$date' AND Time = '$time' AND Nutritionist = '$nutritionist'";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) > 0) {
        echo json_encode(['available' => false]);
    } else {
        echo json_encode(['available' => true]);
    }
} else {
    echo json_encode(['available' => true]);
}
?>
