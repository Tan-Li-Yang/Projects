

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Form</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            margin: 0;
            padding: 20px;
        }
        .form-container {
            background-color: white;
            padding: 30px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            max-width: 600px;
            margin: 0 auto;
        }
        h2 {
            color: #ff9800;
            margin-top: 0;
        }
        input[type="text"],
        input[type="email"],
        input[type="password"],
        select {
            width: 100%;
            padding: 10px;
            margin: 5px 0;
            border: 1px solid #ddd;
            border-radius: 3px;
            box-sizing: border-box;
        }
        .date-of-birth {
            display: flex;
            justify-content: space-between;
        }
        .date-of-birth select {
            width: 32%;
        }
        .gender-selection {
            display: flex;
            justify-content: space-between;
        }
        .gender-selection label {
            width: 48%;
            padding: 10px;
            text-align: center;
            background-color: #f5f5f5;
            border: 1px solid #ddd;
            border-radius: 3px;
            cursor: pointer;
        }
        .gender-selection input[type="radio"] {
            display: none;
        }
        .gender-selection input[type="radio"]:checked + label {
            background-color: #ff9800;
            color: white;
        }
        .payment-method {
            display: flex;
            justify-content: space-between;
            margin: 10px 0;
        }
        .payment-method button {
            width: 48%;
            padding: 10px;
            border: none;
            border-radius: 3px;
            cursor: pointer;
            background-color: #f5f5f5;
        }
        .payment-method button.active {
            background-color: #ff9800;
            color: white;
        }
        .terms {
            margin: 10px 0;
        }
        .submit-btn {
            width: 100%;
            padding: 10px;
            background-color: #ff9800;
            color: white;
            border: none;
            border-radius: 3px;
            cursor: pointer;
            margin-top: 10px;
        }
        @media (max-width: 600px) {
            .form-container {
                padding: 20px;
            }
        }
    </style>
</head>
<body>
    <div class="form-container">
        <h2>Account</h2>
        <input type="text" id="fullName" placeholder="Full Name" aria-label="Full Name">
        <input type="email" id="email" placeholder="Email Address" aria-label="Email Address">
        <input type="password" id="password" placeholder="Password" aria-label="Password">
        
        <h2>Date of Birth</h2>
        <div class="date-of-birth">
            <select id="day" aria-label="Day">
                <option value="">DD</option>
            </select>
            <select id="month" aria-label="Month">
                <option value="">MM</option>
            </select>
            <select id="year" aria-label="Year">
                <option value="">YYYY</option>
            </select>
        </div>
        
        <h2>Gender</h2>
        <div class="gender-selection">
            <input type="radio" id="male" name="gender" value="male">
            <label for="male">Male</label>
            <input type="radio" id="female" name="gender" value="female">
            <label for="female">Female</label>
        </div>
        
        <h2>Payment Details</h2>
        <div class="payment-method">
            <button id="creditCard" class="active">Credit Card</button>
            <button id="paypal">Paypal</button>
        </div>
        <input type="text" id="cardNumber" placeholder="Card Number" aria-label="Card Number">
        <div class="date-of-birth">
            <input type="text" id="cardCVC" placeholder="Card CVC" aria-label="Card CVC">
            <select id="expMonth" aria-label="Expiration Month">
                <option>01 Jan</option>
                <option>02 Feb</option>
                <option>03 Mar</option>
                <option>04 Apr</option>
                <option>05 May</option>
                <option>06 Jun</option>
                <option>07 Jul</option>
                <option>08 Aug</option>
                <option>09 Sep</option>
                <option>10 Oct</option>
                <option>11 Nov</option>
                <option>12 Dec</option>
            </select>
            <select id="expYear" aria-label="Expiration Year">
                <option>2023</option>
                <option>2024</option>
                <option>2025</option>
                <option>2026</option>
                <option>2027</option>
                <option>2028</option>
            </select>
        </div>
        
        <div class="terms">
            <input type="checkbox" id="terms">
            <label for="terms">I accept the terms and conditions for signing up to this service, and hereby confirm I have read the privacy policy.</label>
        </div>
        
        <button class="submit-btn" onclick="submitForm()">Submit</button>
    </div>

    <script>
        // Populate date of birth dropdowns
        const daySelect = document.getElementById('day');
        const monthSelect = document.getElementById('month');
        const yearSelect = document.getElementById('year');

        for (let i = 1; i <= 31; i++) {
            const option = document.createElement('option');
            option.value = i;
            option.textContent = i.toString().padStart(2, '0');
            daySelect.appendChild(option);
        }

        const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        months.forEach((month, index) => {
            const option = document.createElement('option');
            option.value = index + 1;
            option.textContent = month;
            monthSelect.appendChild(option);
        });

        const currentYear = new Date().getFullYear();
        for (let i = currentYear; i >= currentYear - 100; i--) {
            const option = document.createElement('option');
            option.value = i;
            option.textContent = i;
            yearSelect.appendChild(option);
        }

        // Payment method selection
        const creditCardBtn = document.getElementById('creditCard');
        const paypalBtn = document.getElementById('paypal');

        creditCardBtn.addEventListener('click', () => {
            creditCardBtn.classList.add('active');
            paypalBtn.classList.remove('active');
        });

        paypalBtn.addEventListener('click', () => {
            paypalBtn.classList.add('active');
            creditCardBtn.classList.remove('active');
        });

        // Form submission with validation
        function submitForm() {
            // Get values from the form
            const fullName = document.getElementById('fullName').value.trim();
            const email = document.getElementById('email').value.trim();
            const password = document.getElementById('password').value.trim();
            const day = daySelect.value;
            const month = monthSelect.value;
            const year = yearSelect.value;
            const gender = document.querySelector('input[name="gender"]:checked');
            const paymentMethod = creditCardBtn.classList.contains('active') ? 'Credit Card' : 'Paypal';
            const cardNumber = document.getElementById('cardNumber').value.trim();
            const cardCVC = document.getElementById('cardCVC').value.trim();
            const termsAccepted = document.getElementById('terms').checked;

            // Validate fields
            if (!fullName) {
                alert("Please enter your full name.");
                return;
            }
            if (!validateEmail(email)) {
                alert("Please enter a valid email address.");
                return;
            }
            if (!password) {
                alert("Please enter your password.");
                return;
            }
            if (!day || !month || !year) {
                alert("Please select your date of birth.");
                return;
            }
            if (!gender) {
                alert("Please select your gender.");
                return;
            }
            if (paymentMethod === 'Credit Card') {
                if (!cardNumber || !cardCVC) {
                    alert("Please enter your card details.");
                    return;
                }
            }
            if (!termsAccepted) {
                alert("You must accept the terms and conditions.");
                return;
            }

            // If all validations pass
            alert('Form submitted successfully!');
            window.location.href = 'class_booking.php'; // Replace with your actual homepage URL
        }

        // Email validation function
        function validateEmail(email) {
            const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            return regex.test(email);
        }
    </script>
</body>
</html>