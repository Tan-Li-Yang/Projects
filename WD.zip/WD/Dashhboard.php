<?php
session_start();  // Start the session

if (!isset($_SESSION['userinput'])) {
    // Redirect to login page if not logged in
    header("Location: login.php");
    exit();
}           
$email = $_SESSION['userinput'];

include 'Connect.php';
$sql = "SELECT * FROM target WHERE email='$email'";
        $result = mysqli_query($conn, $sql);
        if (mysqli_num_rows($result) > 0) {
            $row = mysqli_fetch_assoc($result);
            $water = $row["water"];
            $weight = $row["weight"];
        }
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
    <link rel="stylesheet" href="DashhboardStyle.css">
</head>

<body>
<header>
        <div class="logo">HuanFitnessPal</div>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <?php
                if (!isset($_SESSION['userinput'])) {
                }else{
                    echo '<li><a href="dashhboard.php">Data</a></li>';
                }
                ?>
                <li><a href="aboutus.php">About US</a></li>
                
            </ul>
        </nav>
        <div class="cta-buttons">
            <?php
                if (!isset($_SESSION['userinput'])) {
                    echo '<button class="cta-button"><a href="register.php">Register</a></button>';
                    echo '<button class="cta-button"><a href="login.php">Login</a></button>';
                }else{
                    echo '<button class="cta-button"><a href="logout.php">Sign Out</a></button>';
                }
            ?>
        </div>
    </header>
  
  
    <main>
      <nav class="main-menu">
        <br><br><br>
        <ul>
        <li class="nav-item" id="dashboardItem">
            <b></b>
            <b></b>
            <a href="Dashhboard.php">
                <i class="fa fa-house nav-icon"></i>
                <span class="nav-text">Dashboard</span>
            </a>
        </li>
            <li class="nav-item dropdown" id="managementItem">
                <b></b>
                <b></b>
                <a href="#" class="dropdown-toggle">
                    <i class="fa fa-user nav-icon"></i>
                    <span class="nav-text">Management</span>
                    <i class="fa fa-chevron-down dropdown-icon"></i>
                </a>
                <ul class="dropdown-menu">
                    <li><a href="weight.php"><i class="fa fa-weight-scale"></i> Weight</a></li>
                    <li><a href="exercise.php"><i class="fa fa-dumbbell"></i> Exercise</a></li>
                    <li><a href="water.php"><i class="fa fa-glass-water"></i> Water Consumption</a></li>
                    <li><a href="calory.php"><i class="fa fa-cal"></i> Calory</a></li>
                    <li><a href="nutritionist.php"><i class="fa fa-nut"></i> Nutritionist</a></li>
                </ul>
            </li>
            <li class="nav-item">
                <b></b>
                <b></b>
                <a href="appointment.php">
                    <i class="fa fa-calendar-check nav-icon"></i>
                    <span class="nav-text">Appointment</span>
                </a>
            </li>
            <li class="nav-item">
                <b></b>
                <b></b>
                <a href="profile.php">
                    <i class="fa fa-calendar-check nav-icon"></i>
                    <span class="nav-text">Profile</span>
                </a>
            </li>
            <li class="nav-item">
                <b></b>
                <b></b>
                <a href="class_booking.php">
                    <i class="fa fa-calendar-check nav-icon"></i>
                    <span class="nav-text">Fitness classes</span>
                </a>
            </li>
        </ul>
    </nav>

        <section class="content">
            <div class="left-content">
                <div class="activities">
                    <h1>Popular Activities</h1>
                    <div class="activity-container">
                        <div class="image-container img-one">
                            <img src="https://github.com/ecemgo/mini-samples-great-tricks/assets/13468728/467cf682-03fb-4fae-b129-5d4f5db304dd" alt="tennis" />
                            <div class="overlay">
                                <h3>Tennis</h3>
                                <button class="add-now-btn" onclick="addWindow('exercise', 'Tennis')">Add Now</button>
                            </div>
                        </div>

                        <div class="image-container img-two">
                            <img src="https://github.com/ecemgo/mini-samples-great-tricks/assets/13468728/3bab6a71-c842-4a50-9fed-b4ce650cb478" alt="hiking" />
                            <div class="overlay">
                                <h3>Hiking</h3>
                                <button class="add-now-btn" onclick="addWindow('exercise', 'Hiking')">Add Now</button>
                            </div>
                        </div>

                        <div class="image-container img-three">
                            <img src="https://github.com/ecemgo/mini-samples-great-tricks/assets/13468728/c8e88356-8df5-4ac5-9e1f-5b9e99685021" alt="running" />
                            <div class="overlay">
                                <h3>Running</h3>
                                <button class="add-now-btn" onclick="addWindow('exercise', 'Running')">Add Now</button>
                            </div>
                        </div>

                        <div class="image-container img-four">
                            <img src="https://github.com/ecemgo/mini-samples-great-tricks/assets/13468728/69437d08-f203-4905-8cf5-05411cc28c19" alt="cycling" />
                            <div class="overlay">
                                <h3>Cycling</h3>
                                <button class="add-now-btn" onclick="addWindow('exercise', 'Cycling')">Add Now</button>
                            </div>
                        </div>

                        <div class="image-container img-five">
                            <img src="https://github.com/ecemgo/mini-samples-great-tricks/assets/13468728/e1a66078-1927-4828-b793-15c403d06411" alt="yoga" />
                            <div class="overlay">
                                <h3>Yoga</h3>
                                <button class="add-now-btn" onclick="addWindow('exercise', 'Yoga')">Add Now</button>
                            </div>
                        </div>

                        <div class="image-container img-six">
                            <img src="https://github.com/ecemgo/mini-samples-great-tricks/assets/13468728/7568e0ff-edb5-43dd-bff5-aed405fc32d9" alt="swimming" />
                            <div class="overlay">
                                <h3>Swimming</h3>
                                <button class="add-now-btn" onclick="addWindow('exercise', 'Swimming')">Add Now</button>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="left-bottom">
                    <div class="weekly-schedule">
                        <h1>Exercise Record</h1>
                        <div class="calendar" id="exerciseRecords">
                            <!-- Exercise records will be dynamically inserted here -->
                        </div>
                    </div>

                    <div class="appointment-info">
                        <h1>Appointment</h1>
                        <div class="appointment-info-container" id="appointmentInfo">
                            <!-- Appointment info will be dynamically inserted here -->
                        </div>
                    </div>
                </div>
            </div>

            <div class="right-content">
                <div class="user-info">
                    <h2>Water Consumption</h2>
                </div>

                <div class="active-calories">
                    <h1 style="align-self: flex-start">Active Status</h1>
                    <div class="active-calories-container">
                        <div class="box" id="waterConsumptionBox">
                            <!-- Water consumption progress will be dynamically updated here -->
                        </div>
                        <div class="calories-content" id="waterConsumptionInfo">
                            <!-- Water consumption info will be dynamically updated here -->
                        </div>
                    </div>
                </div>

                <div class="user-info">
        <h2>Calories</h2>
    </div>

    <div class="active-calories">
        <h1 style="align-self: flex-start">Active Status</h1>
        <div class="active-calories-container">
            <div class="box" id="caloriesBox">
                <!-- Calories progress will be dynamically updated here -->
            </div>
            <div class="calories-content" id="caloriesInfo">
                <!-- Calories info will be dynamically updated here -->
            </div>
        </div>
    </div>

                <div class="friends-activity"> <br>
                    <h2>Body Weight</h2> <br>
                    <div class="card-container">
                        <div class="card">
                            <div class="Bodyweight">
                                <img src="res/Weight.png">
                                <h6 id="currentWeight"><span>Current Weight :</span> Loading...</h6>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>
    <script>
        // Ensure this is defined before your main JS file
        const targetV = <?php echo json_encode($water); ?>; // Pass PHP variable to JavaScript
        const targetW = <?php echo json_encode($weight); ?>;
    </script>
    <script src="Dashboardjavascript.js"></script>
</body>
</html>
