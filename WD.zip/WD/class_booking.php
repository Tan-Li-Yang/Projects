<?php

include 'Connect.php';
session_start();  // Start the session
ob_start();

if (!isset($_SESSION['userinput'])) {
    // Redirect to login page if not logged in
    header("Location: login.php");
    exit();
}

$userName = $_SESSION['userinput'];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    $classes = []; // This will store selected class info

    // Check which classes are selected and store data in the array
    if (isset($_POST['yoga']) && isset($_POST['yoga_day'])) {
        $classes[] = [
            'class_name' => 'Yoga',
            'day' => $_POST['yoga_day'],
            'price' => 80.00
        ];
    }

    if (isset($_POST['pilates']) && isset($_POST['pilates_day'])) {
        $classes[] = [
            'class_name' => 'Pilates',
            'day' => $_POST['pilates_day'],
            'price' => 100.00
        ];
    }

    if (isset($_POST['strength_training']) && isset($_POST['strength_training_day'])) {
        $classes[] = [
            'class_name' => 'Strength Training',
            'day' => $_POST['strength_training_day'],
            'price' => 120.00
        ];
    }

    // Store the classes into the database
    foreach ($classes as $class) {
        // Check if the user is already registered for the class
        $checkSql = "SELECT * FROM fitness_class_subscription WHERE username = ? AND class_name = ? AND status = 'active'";
        $checkStmt = mysqli_prepare($conn, $checkSql);
        mysqli_stmt_bind_param($checkStmt, "ss", $userName, $class['class_name']);
        mysqli_stmt_execute($checkStmt);
        mysqli_stmt_store_result($checkStmt);

        // Check if the user is already registered
        $isRegistered = mysqli_stmt_num_rows($checkStmt) > 0;
        mysqli_stmt_close($checkStmt);

        if ($isRegistered) {
            // Update the class day if already registered
            $updateSql = "UPDATE fitness_class_subscription SET class_day = ? WHERE username = ? AND class_name = ?";
            $updateStmt = mysqli_prepare($conn, $updateSql);
            mysqli_stmt_bind_param($updateStmt, "sss", $class['day'], $userName, $class['class_name']);
            if (mysqli_stmt_execute($updateStmt)) {
                echo $class['class_name'] . " class day updated successfully.<br>";
            } else {
                echo "Error updating data: " . mysqli_error($conn) . "<br>";
            }
            mysqli_stmt_close($updateStmt);

        } else {
            // Register the user for the class if not already registered
            $insertSql = "INSERT INTO fitness_class_subscription (username, class_name, class_day, price_per_month, status) VALUES (?, ?, ?, ?, 'active')";
            $insertStmt = mysqli_prepare($conn, $insertSql);
            mysqli_stmt_bind_param($insertStmt, "sssi", $userName, $class['class_name'], $class['day'], $class['price']);
            if (mysqli_stmt_execute($insertStmt)) {
                echo "Registered for " . $class['class_name'] . " successfully.<br>";
            } else {
                echo "Error inserting data: " . mysqli_error($conn) . "<br>";
            }
            mysqli_stmt_close($insertStmt);
        }
    }

    // Redirect to success page after insertion
    header("Location: payment.php");
    exit();
}
?>






<!DOCTYPE HTML>
<html lang="en">
   <head>
       <meta charset="UTF-8">
       <meta name="viewport" content="width=device-width, initial-scale=1.0">
       <title>Class Registration</title>
       <style>
          *,
*::before,
*::after {
  box-sizing: border-box;
  padding: 0;
  margin: 0;
}
  header {
            background-color: #fff;
            padding: 1rem 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        .logo{
            font:bold;
            color:green;
            font-size: 1.8rem;
            font-weight: 700;
        }
        nav {
            user-select: none;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            -o-user-select: none;
        }

        nav ul {
            list-style: none;
            outline:0;
            flex-direction: column;
        }

        nav ul li {
            display: inline-block;
            outline:0;
            margin-right: 25px; /* Set gap to 25px */
        }

        nav ul li a {
            text-decoration: none;
            color: #333;
            font-weight: bold;
        }
        .cta-buttons {
            display: flex;
            gap: 0.5rem; /* Adjust the spacing between the buttons */
        }
        .cta-button {
            background-color: #ff4081;
            color: #fff;
            border: none;
            padding: 0.5rem 1rem;
            border-radius: 5px;
            cursor: pointer;
            font-weight: bold;
        }
        .cta-button a{
          text-decoration:none;
          color:white;
        }


body {
    margin: 0; /* Remove default body margin */
    font-family: "Nunito", sans-serif;
    display: flex;
    flex-direction: column;/* Stacks the header and main content vertically */
    min-height: 100vh;
    background-image: url(https://github.com/ecemgo/mini-samples-great-tricks/assets/13468728/5baf8325-ed69-40b0-b9d2-d8c5d2bde3b0);
    background-repeat: no-repeat;
    background-size: cover;
}

/* MAIN MENU */

main {
    display: grid;
    grid-template-columns: 13% 87%;
    width: 97%;
    margin: 40px auto;
    background: rgb(254, 254, 254);
    box-shadow: 0 0.5px 0 1px rgba(255, 255, 255, 0.23) inset,
      0 1px 0 0 rgba(255, 255, 255, 0.66) inset, 0 4px 16px rgba(0, 0, 0, 0.12);
    border-radius: 15px;
    z-index: 10;
}

.main-menu {
    overflow: hidden;
    background: rgb(73, 57, 113);
    padding-top: 10px;
    border-radius: 15px 0 0 15px;
    font-family: "Roboto", sans-serif;
    transition: all 0.3s ease;
}

.nav-item {
    position: relative;
    display: block;
    width: 100%;
    max-width: 250px;
}

.nav-item a {
    position: relative;
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: flex-start;
    color: #fff;
    font-size: 1rem;
    padding: 15px 15px;
    margin-left: 10px;
    border-top-left-radius: 20px;
    border-bottom-left-radius: 20px;
    transition: all 0.3s ease;
}

.nav-item b:nth-child(1) {
    position: absolute;
    top: -15px;
    height: 15px;
    width: 100%;
    background: #fff;
    display: none;
}

.nav-item b:nth-child(1)::before {
    content: "";
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    border-bottom-right-radius: 20px;
    background: rgb(73, 57, 113);
}

.nav-item b:nth-child(2) {
    position: absolute;
    bottom: -15px;
    height: 15px;
    width: 100%;
    background: #fff;
    display: none;
}

.nav-item b:nth-child(2)::before {
    content: "";
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    border-top-right-radius: 20px;
    background: rgb(73, 57, 113);
}

.nav-item.active b:nth-child(1),
.nav-item.active b:nth-child(2) {
    display: block;
}

.nav-item.active a {
    text-decoration: none;
    color: #000;
    background: rgb(254, 254, 254);
}

.nav-icon {
    width: 60px;
    height: 20px;
    font-size: 20px;
    text-align: center;
}

.nav-text {
    display: block;
    width: 190px;
    height: 20px;
}

/* New styles for dropdown */
.dropdown-menu {
  display: none;
  list-style-type: none;
  border-radius: 15px 0px 0px 15px;
  background-color:#c2c2c2;
  margin-left:20px;
  padding-bottom: 10px;
  max-height: 0;
    overflow: hidden;
    transition: max-height 0.3s ease, opacity 0.3s ease;
    opacity: 0;
}

.dropdown-menu li {
  padding-top:10px;
}

.dropdown-menu i {
    margin-right: 10px;
    font-size: 0.9em;
}

.dropdown-menu a {
  text-decoration: none;
  font-size: 0.9rem;
  padding: 10px 10px;
  display: block;
  border-radius: 0%;
  width: 140px;
  max-width:150px;
  border-radius: 10px;
  transition: all 0.3s ease;
}

.dropdown-menu a:hover {
    background-color: rgba(255, 255, 255, 0.2);
    transform: translateX(5px);
}

.nav-item.dropdown.active .dropdown-menu {
    display: block;
    max-height: 300px;
    opacity: 1;
}

.nav-item.dropdown.active > a {
    color: #000;
    background: rgb(254, 254, 254);
}

.nav-item.dropdown.active b:nth-child(1),
.nav-item.dropdown.active b:nth-child(2) {
    display: block;
}

/* Enhanced styles */
.nav-item:not(.active) a:hover {
    background-color: rgba(255, 255, 255, 0.1);
}

.dropdown-toggle {
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.dropdown-icon {
    transition: transform 0.3s ease;
}

.nav-item.dropdown.active .dropdown-icon {
    transform: rotate(180deg);
}

.dropdown-menu i {
    margin-right: 10px;
    font-size: 0.9em;
}

/* Subtle hover effect for all nav items */
.nav-item:not(.active):hover {
    background-color: rgba(255, 255, 255, 0.05);
}

/* Improved active state styling */
.nav-item.active a,
.nav-item.dropdown.active > a {
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
}

/* Add a subtle line to separate nav items */
.nav-item:not(:last-child) {
    border-bottom: 1px solid rgba(255, 255, 255, 0.1);
}

.container {
    background-color: white;
    width: 100%;
    max-width: 600px;
    border-radius: 10px;
    padding: 20px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    margin: 0 auto; /* Center the form horizontally */
}


           h3 {
               text-align: center;
               color: #333;
               margin-bottom: 20px;
           }

           label {
               display: block;
               font-size: 16px;
               margin-bottom: 8px;
               color: #555;
           }

           input[type="checkbox"], input[type="radio"] {
               margin-right: 10px;
           }

           .radio-group {
               display: none;
               margin-top: 10px;
           }

           .radio-group input[type="radio"] {
               margin-right: 5px;
           }

           .price-container {
               font-size: 18px;
               font-weight: bold;
               margin-top: 20px;
               padding: 10px;
               background-color: #e0f7fa;
               border-radius: 8px;
               text-align: center;
           }

           .form-group {
               margin-bottom: 20px;
           }

           .btn {
               display: block;
               width: 100%;
               padding: 15px;
               background-color: #4CAF50;
               color: white;
               text-align: center;
               border: none;
               border-radius: 8px;
               font-size: 16px;
               cursor: pointer;
               transition: background-color 0.3s ease;
           }

           .btn:hover {
               background-color: #45a049;
           }

           .subscription {
            margin-top: 20px; /* Add some space above the section */
            background-color: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            max-width: 600px;
            width: 100%;
            text-align: center;
            margin-left: auto;
            margin-right: auto; /* Center the div horizontally */
        }

        .dropout-btn {
            color: #dc3545;
            text-decoration: none;
            padding: 5px 10px;
            border: 1px solid #dc3545;
            border-radius: 5px;
            transition: all 0.3s ease;
        }

        .dropout-btn:hover {
            background-color: #dc3545;
            color: white;
        }

        .subscription {
            margin-top: 20px;
            background-color: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            max-width: 600px;
            width: 100%;
            text-align: center;
            margin-left: auto;
            margin-right: auto;
        }

        .subscription ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .subscription li {
            padding: 10px 0;
            border-bottom: 1px solid #eee;
        }

        .subscription a {
            color: #dc3545;
            text-decoration: none;
            margin-left: 10px;
        }

        .subscription a:hover {
            text-decoration: underline;
        }
           @media (max-width: 600px) {
               .container {
                   width: 90%;
                   padding: 15px;
               }

               .btn {
                   font-size: 14px;
               }
           }

           .btn-class {
            width: 100%;
            padding: 15px;
            margin: 10px 0;
            border: 2px solid #ccc;
            border-radius: 15px;
            box-shadow: 2px 2px 10px rgba(0, 0, 0, 0.2);
            background-color: #f1f1f1;
            text-align: left;
            font-size: 18px;
            cursor: pointer;
        }

        /* Hover effect for button */
        .btn-class:hover {
            background-color: #e0e0e0;
        }

        /* Dropdown content container */
        .dropdown-content {
            display: none;
            padding: 10px;
            background-color: #fafafa;
            border: 1px solid #ddd;
            border-radius: 10px;
            margin-top: 5px;
        }

        /* Show dropdown content when clicked */
        .show {
            display: block;
        }

        /* Dropout button styling */
        .btn-dropout {
            margin-top: 10px;
            padding: 10px;
            background-color: #f44336;
            color: white;
            border: none;
            border-radius: 10px;
            cursor: pointer;
        }

        .btn-dropout:hover {
            background-color: #d32f2f;
        }
       </style>
   </head>
   <body>
   <header>
        <div class="logo">HuanFitnessPal</div>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <?php
                if (!isset($_SESSION['userinput'])) {
                }else{
                    echo '<li><a href="dashhboard.php">Data</a></li>';
                }
                ?>
                <li><a href="aboutus.php">About US</a></li>
                
            </ul>
        </nav>
        <div class="cta-buttons">
            <?php
                if (!isset($_SESSION['userinput'])) {
                    echo '<button class="cta-button"><a href="register.php">Register</a></button>';
                    echo '<button class="cta-button"><a href="login.php">Login</a></button>';
                }else{
                    echo '<button class="cta-button"><a href="logout.php">Sign Out</a></button>';
                }
            ?>
        </div>
    </header>
  
  
    <main>
      <nav class="main-menu">
        <br><br><br>
        <ul>
            <li class="nav-item">
                <b></b>
                <b></b>
                <a href="Dashhboard.php">
                    <i class="fa fa-house nav-icon"></i>
                    <span class="nav-text">Dashboard</span>
                </a>
            </li>
            <li class="nav-item dropdown" id="managementItem">
                <b></b>
                <b></b>
                <a href="#" class="dropdown-toggle">
                  <i class="fa fa-user nav-icon"></i>
                  <span class="nav-text">Management</span>
                  <i class="fa fa-chevron-down dropdown-icon"></i>
              </a>
              <ul class="dropdown-menu">
                  <li><a href="weight.php"><i class="fa fa-weight-scale"></i> Weight</a></li>
                  <li><a href="exercise.php"><i class="fa fa-dumbbell"></i> Exercise</a></li>
                  <li><a href="water.php"><i class="fa fa-glass-water"></i> Water Consumption</a></li>
                  <li><a href="calory.php"><i class="fa fa-cal"></i> Calory</a></li>
                  <li><a href="nutritionist.php"><i class="fa fa-nut"></i> Nutritionist</a></li>
              </ul>
            </li>
            <li class="nav-item">
                <b></b>
                <b></b>
                <a href="appointment.php">
                    <i class="fa fa-calendar-check nav-icon"></i>
                    <span class="nav-text">Appointment</span>
                </a>
            </li>
            <li class="nav-item">
                <b></b>
                <b></b>
                <a href="profile.php">
                    <i class="fa fa-calendar-check nav-icon"></i>
                    <span class="nav-text">Profile</span>
                </a>
            </li>
            <li class="nav-item active" id="bookingItem">
                <b></b>
                <b></b>
                <a href="class_booking.php">
                    <i class="fa fa-calendar-check nav-icon"></i>
                    <span class="nav-text">Fitness classes</span>
                </a>
            </li>
        </ul>
    </nav>
      <form id="fitness-class" name="fitness-class" method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" class="container">
           <h3>Class Registration</h3>

                  <!-- Yoga Button -->
        <div class="form-group">    
            <button type="button" class="btn-class" onclick="toggleDropdown('yoga-dropdown');">Yoga (RM80/month)</button>
            <div id="yoga-dropdown" class="dropdown-content">
                <label>Choose a day:</label>
                <input type="radio" name="yoga_day" value="Monday" onclick="validateDay('yoga', 'Monday')"> Monday 6pm to 7pm<br>
                <input type="radio" name="yoga_day" value="Saturday" onclick="validateDay('yoga', 'Saturday')"> Saturday 10am to 11am<br>
                <input type="radio" name="yoga_day" value="Sunday" onclick="validateDay('yoga', 'Sunday')"> Sunday 10am to 11am
                <input type="hidden" name="yoga">
                
            </div>
        </div>

        <!-- Pilates Button -->
        <div class="form-group">
            <button type="button" class="btn-class" onclick="toggleDropdown('pilates-dropdown');">Pilates (RM100/month)</button>
            <div id="pilates-dropdown" class="dropdown-content">
                <label>Choose a day:</label>
                <input type="radio" name="pilates_day" value="Tuesday" onclick="validateDay('pilates', 'Tuesday')"> Tuesday 6pm to 7pm<br>
                <input type="radio" name="pilates_day" value="Friday" onclick="validateDay('pilates', 'Friday')"> Friday 6pm to 7pm<br>
                <input type="radio" name="pilates_day" value="Saturday" onclick="validateDay('pilates', 'Saturday')"> Saturday 4pm to 5pm
                <input type="hidden" name="pilates">
               
            </div>
        </div>

        <!-- Strength Training Button -->
        <div class="form-group">
            <button type="button" class="btn-class" onclick="toggleDropdown('strength-training-dropdown');">Strength Training (RM120/month)</button>
            <div id="strength-training-dropdown" class="dropdown-content">
                <label>Choose a day:</label>
                <input type="radio" name="strength_training_day" value="Wednesday" onclick="validateDay('strength_training', 'Wednesday')"> Wednesday 6pm to 7pm<br>
                <input type="radio" name="strength_training_day" value="Thursday" onclick="validateDay('strength_training', 'Thursday')"> Thursday 6pm to 7pm<br>
                <input type="radio" name="strength_training_day" value="Sunday" onclick="validateDay('strength_training', 'Sunday')"> Sunday 4pm to 5pm
                <input type="hidden" name="strength_training">
                
            </div>
        </div>

          

           <div class="price-container">Total price: RM<span id="totalPrice">0</span></div>

           <input type="button" value="Save" class="btn" onclick="submitForm()">

          
        </div>
        <div class="subscription">
    <h3>Your Active Subscriptions</h3>
    <ul>
        <?php
        // Fetch the active subscriptions from the database
        $userName = $_SESSION['userinput'];
        $sql = "SELECT * FROM fitness_class_subscription WHERE username = ? AND status = 'active'";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "s", $userName);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        // Display each active subscription with a Drop Out link
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<li>" . $row['class_name'] . " - " . $row['class_day'] . " <a href='class_booking.php?drop_out=true&class_name=" . urlencode($row['class_name']) . "' class='dropout-btn'>Drop Out</a></li>";
        }

        mysqli_stmt_close($stmt);
        
        
        ?>
    </ul>
</div>
       </form>
      


    </main>
    <?php
// Drop out from a class
if (isset($_GET['drop_out']) && isset($_GET['class_name'])) {
    $class_name = $_GET['class_name'];
    $userName = $_SESSION['userinput']; // Assuming the username is stored in the session

    // Update the subscription status to 'inactive'
    $sql = "UPDATE fitness_class_subscription SET status = 'inactive' WHERE username = ? AND class_name = ? AND status = 'active'";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "ss", $userName, $class_name);
    mysqli_stmt_execute($stmt);
    header("Location: " . $_SERVER['PHP_SELF']); 
    exit();
    

}
?>

      

       <script>
document.addEventListener('DOMContentLoaded', function() {
    // Set initial active state for appointment page
    const bookingItem = document.getElementById('bookingItem');
    bookingItem.classList.add('active');

    // Remove active class from all items
    function removeActiveClass() {
        const items = document.querySelectorAll('.nav-item');
        items.forEach(item => item.classList.remove('active'));
    }

    // Handle click on Dashboard item
    const dashboardItem = document.querySelector('.nav-item:first-child');
    dashboardItem.addEventListener('click', function(e) {
        removeActiveClass();
        this.classList.add('active');
    });

    // Handle click on Management dropdown
    const managementItem = document.getElementById('managementItem');
    const dropdownToggle = managementItem.querySelector('.dropdown-toggle');
    dropdownToggle.addEventListener('click', function(e) {
        e.preventDefault();
        e.stopPropagation();
        removeActiveClass();
        managementItem.classList.toggle('active');
    });

    // Close dropdown when clicking outside
    document.addEventListener('click', function(e) {
        if (!managementItem.contains(e.target)) {
            managementItem.classList.remove('active');
        }
    });

    // Prevent dropdown from closing when clicking inside
    managementItem.addEventListener('click', function(e) {
        e.stopPropagation();
    });

    // Handle clicks on dropdown menu items
    const dropdownMenuItems = managementItem.querySelectorAll('.dropdown-menu a');
    dropdownMenuItems.forEach(item => {
        item.addEventListener('click', (e) => {
            removeActiveClass();
            managementItem.classList.add('active');
        });
    });

    // Add hover effect to nav items
    const navItems = document.querySelectorAll('.nav-item');
    navItems.forEach(item => {
        item.addEventListener('mouseenter', () => {
            if (!item.classList.contains('active')) {
                item.style.backgroundColor = 'rgba(255, 255, 255, 0.05)';
            }
        });
        item.addEventListener('mouseleave', () => {
            if (!item.classList.contains('active')) {
                item.style.backgroundColor = '';
            }
        });
    });

});

function calculateTotalPrice() {
        let totalPrice = 0;
        
        if (document.querySelector('input[name="yoga_day"]:checked')) {
            totalPrice += 80;
        }
        if (document.querySelector('input[name="pilates_day"]:checked')) {
            totalPrice += 100;
        }
        if (document.querySelector('input[name="strength_training_day"]:checked')) {
            totalPrice += 120;
        }

        document.getElementById('totalPrice').textContent = totalPrice;
    }

    // Call calculateTotalPrice when radio buttons are clicked
    document.querySelectorAll('input[type="radio"]').forEach(function(radio) {
        radio.addEventListener('click', calculateTotalPrice);
    });

           // Function to toggle the radio group visibility based on checkbox click
           function toggleDropdown(dropdownId) {
        var dropdown = document.getElementById(dropdownId);
        if (dropdown.classList.contains('show')) {
            dropdown.classList.remove('show');
        } else {
            var allDropdowns = document.querySelectorAll('.dropdown-content');
            allDropdowns.forEach(function(dd) {
                dd.classList.remove('show');
            });
            dropdown.classList.add('show');
        }
    }

    // Function to validate that the day chosen is not already taken
    function validateDay(classType, day) {
        // Prevent choosing the same day for different classes
        var classes = ['yoga', 'pilates', 'strength_training'];
        for (var i = 0; i < classes.length; i++) {
            if (classes[i] !== classType) {
                var otherRadio = document.querySelector('input[name=' + classes[i] + '_day][value="' + day + '"]');
                if (otherRadio && otherRadio.checked) {
                    alert("You cannot choose " + day + " for " + classes[i].charAt(0).toUpperCase() + classes[i].slice(1) + " class. Please select a different day.");
                    otherRadio.checked = false; // Uncheck the conflicting radio
                }
            }
        }
    }
    function setClass(className, dayName) {
    document.getElementById('selected_class').value = className;
    const selectedDay = document.querySelector(`input[name="${dayName}"]:checked`);
    if (selectedDay) {
        document.getElementById('selected_day').value = selectedDay.value;
    } else {
        alert('Please select a day before registering.');
        return; // Prevent form submission if no day is selected
    }
    document.getElementById('fitness-class').submit(); // Submit the form
    }




    function submitForm() {
    const form = document.getElementById('fitness-class');
    
    // Submit the form using AJAX
    const xhr = new XMLHttpRequest();
    xhr.open("POST", form.action, true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

    // Handle response from the server
    xhr.onreadystatechange = function () {
        if (xhr.readyState === XMLHttpRequest.DONE) {
            if (xhr.status === 200) {
                // Redirect to payment.php on successful submission
                window.location.href = 'payment.php';
            } else {
                // Handle errors if needed
                console.error('Error storing data:', xhr.responseText);
            }
        }
    };

    // Create the form data to send
    const formData = new FormData(form);
    const params = new URLSearchParams(formData).toString();
    
    // Send the form data
    xhr.send(params);
}

       </script>

   </body>
</html>
<?php
ob_end_flush();
?>