<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Huan Fitness Centre</title>
    <link rel="stylesheet" href="DashhboardStyle.css">
</head>

<body>

    <header>
        <div class="logo">HuanFitnessPal</div>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <?php
                if (!isset($_SESSION['userinput'])) {
                }else{
                    echo '<li><a href="dashhboard.php">Data</a></li>';
                }
                ?>
                <li><a href="aboutus.php">About US</a></li>
                
            </ul>
        </nav>
        <div class="cta-buttons">
            <?php
                if (!isset($_SESSION['userinput'])) {
                    echo '<button class="cta-button"><a href="register.php">Register</a></button>';
                    echo '<button class="cta-button"><a href="login.php">Login</a></button>';
                }else{
                    echo '<button class="cta-button"><a href="logout.php">Sign Out</a></button>';
                }
            ?>
        </div>
    </header>

    <div class="about-content">
        <p>
            Welcome to Huan Fitness Centre, where our mission is to guide you toward a healthier and more vibrant future. Established in 2010 in Klang Valley, we have been dedicated to helping individuals achieve their fitness goals through personalized physical training and dietary consultation. We believe that a balanced lifestyle is the foundation of long-term well-being, and we are here to support you every step of the way.
        </p>
        <br>
        <p>
            At Huan Fitness Centre, we offer a wide range of fitness classes, tailored to all levels, for an affordable monthly fee between RM50 and RM100. In addition, our members have the unique opportunity to consult with our in-house professional nutritionist for personalized dietary advice. With a small fee of RM20 per session, you can gain insights into how to nourish your body based on your specific needs and goals.
        </p>
        <br>
        <p>
            As advocates of the United Nations Sustainable Development Goal (SDG) 3: Good Health and Well-being, we are committed to promoting a healthier lifestyle for all. In line with this vision, we are excited to introduce our upcoming web application, "HuanFitnessPal." This app will empower our members to track their body weight, water consumption, and exercise routines—helping you stay on top of your health and fitness journey.
        </p>
        <br>
        <p>
            Join us today at Huan Fitness Centre, and together, let's build a healthier future!
        </p>
    </div>

</body>

</html>
