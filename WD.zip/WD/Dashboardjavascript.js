document.addEventListener('DOMContentLoaded', function() {
    const dashboardItem = document.querySelector('.nav-item:not(.dropdown)');
    const managementItem = document.querySelector('.nav-item.dropdown');
    const dropdownToggle = managementItem.querySelector('.dropdown-toggle');

    function removeActiveClass() {
        const items = document.querySelectorAll('.nav-item');
        items.forEach(item => item.classList.remove('active'));
    }

    // Set initial active state based on current page
    if (window.location.href.includes('Dashhboard.php')) {
        dashboardItem.classList.add('active');
    }

    // Handle click on Dashboard item
    dashboardItem.addEventListener('click', function(e) {
        removeActiveClass();
        this.classList.add('active');
    });

    // Handle click on Management dropdown
    dropdownToggle.addEventListener('click', function(e) {
        e.preventDefault();
        e.stopPropagation();
        removeActiveClass();
        managementItem.classList.toggle('active');
    });

    // Close dropdown when clicking outside
    document.addEventListener('click', function(e) {
        if (!managementItem.contains(e.target)) {
            managementItem.classList.remove('active');
        }
    });

    // Prevent dropdown from closing when clicking inside
    managementItem.addEventListener('click', function(e) {
        e.stopPropagation();
    });

    // Handle clicks on dropdown menu items
    const dropdownMenuItems = managementItem.querySelectorAll('.dropdown-menu a');
    dropdownMenuItems.forEach(item => {
        item.addEventListener('click', (e) => {
            removeActiveClass();
            managementItem.classList.add('active');
        });
    });

    // Add hover effect to nav items
    const navItems = document.querySelectorAll('.nav-item');
    navItems.forEach(item => {
        item.addEventListener('mouseenter', () => {
            if (!item.classList.contains('active')) {
                item.style.backgroundColor = 'rgba(255, 255, 255, 0.05)';
            }
        });
        item.addEventListener('mouseleave', () => {
            if (!item.classList.contains('active')) {
                item.style.backgroundColor = '';
            }
        });
    });

    fetchDashboardData();
});

function fetchDashboardData() {
    fetch('get_dashboard_data.php')
        .then(response => response.json())
        .then(data => {
            updateExerciseRecords(data.exerciseRecords);
            updateAppointmentInfo(data.appointment);
            updateWaterConsumption(data.waterConsumption);
            updateCalories(data.caloriesBurned, data.calorieTarget);
            updateBodyWeight(data.latestWeight);
        })
        .catch(error => console.error('Error fetching dashboard data:', error));
}

function updateExerciseRecords(records) {
    const container = document.getElementById('exerciseRecords');
    container.innerHTML = '';

    records.forEach(record => {
        const date = new Date(record.Date);
        const recordElement = document.createElement('div');
        recordElement.className = 'day-and-activity';
        recordElement.innerHTML = `
            <div class="day">
                <h1>${date.getDate()}</h1>
                <p>${date.toLocaleString('default', { month: 'short' })}</p>
            </div>
            <div class="activity">
                <h2>${record.Type}</h2>
            </div>
            <div class="calories">${record.Calory} kcal</div>
        `;
        container.appendChild(recordElement);
    });
}

function updateAppointmentInfo(appointment) {
    const container = document.getElementById('appointmentInfo');
    if (appointment) {
        container.innerHTML = `
            <div class="best-item box-one">
                <p class="appointment-info-font">${appointment.Nutritionist}</p>
                <img src="res/Doctor.png" alt="Doctor" />
            </div>
            <div class="best-item box-two">
                <p class="appointment-info-font">${appointment.Date}</p>
                <img src="res/Date.gif" alt="Date" />
            </div>
            <div class="best-item box-three">
                <p>${appointment.Time}</p>
                <img src="res/Time.png" alt="Time" />
            </div>
        `;
    } else {
        container.innerHTML = '<p>No upcoming appointments</p>';
    }
}

function updateWaterConsumption(consumption) {
    const target = parseFloat(targetV); 
    const percentage = Math.min((consumption / target) * 100, 100);

    const boxElement = document.getElementById('waterConsumptionBox');
    boxElement.innerHTML = `
        <div class="circle" style="--i: ${percentage}%;">
            <h2>${percentage.toFixed(0)}<small>%</small></h2>
        </div>
    `;

    const infoElement = document.getElementById('waterConsumptionInfo');
    infoElement.innerHTML = `
        <p><span>Target:</span><br> ${target.toFixed(2)} ML</p>
        <p><span>Today :</span><br> ${consumption.toFixed(2)} ML</p>
    `;
}

function updateCalories(caloriesBurned, calorieTarget) {
    const percentage = Math.min((caloriesBurned / calorieTarget) * 100, 100);

    const boxElement = document.getElementById('caloriesBox');
    boxElement.innerHTML = `
        <div class="circle" style="--i: ${percentage}%;">
            <h2>${percentage.toFixed(0)}<small>%</small></h2>
        </div>
    `;

    const infoElement = document.getElementById('caloriesInfo');
    infoElement.innerHTML = `
        <p><span>Target:</span><br> ${calorieTarget.toFixed(2)} kcal</p>
        <p><span>Today:</span><br> ${caloriesBurned.toFixed(2)} kcal</p>
    `;
}

function updateBodyWeight(weight) {
    const target = parseFloat(targetW);
    const weightElement = document.getElementById('currentWeight');
    weightElement.innerHTML = `<span>Current Weight :</span><br> ${weight} KG<br>
                               <span>Target Weight :</span><br> ${targetW} KG`;
}

function addWindow(action, exerciseType = '') {
    const url = `add.php?action=${action}`;
    const width = 540;
    const height = 311;
    const left = (screen.width - width) / 2;
    const top = (screen.height - height) / 2;

    const options = `width=${width},height=${height},top=${top},left=${left}, resizable=no`;

    const popupWindow = window.open(url, 'AddWindow', options);

    if (popupWindow) {
        popupWindow.onload = function() {
            if (exerciseType) {
                const typeInput = popupWindow.document.getElementById('type');
                if (typeInput) {
                    typeInput.value = exerciseType;
                }
            }
        };
    } else {
        alert('Please allow popups for this website.');
    }
}