<?php

$Identifier = empty($_POST["Id"]) ? "" : $_POST["Id"];
$Edate = empty($_POST["Edate"]) ? "" : $_POST["Edate"];
$Rdate = empty($_POST["Rdate"]) ? "" : $_POST["Rdate"];
$time = empty($_POST["time"]) ? "" : $_POST["time"];
$stime = empty($_POST["stime"]) ? "" : $_POST["stime"];

include 'Connect.php';
session_start();
$email = $_SESSION['userinput'];

if ($Identifier === "W") { // Add weight record into database
    $sql_check = "SELECT * FROM weight WHERE Date='$Edate' AND email='$email'";
    $result = mysqli_query($conn, $sql_check);

    if (mysqli_num_rows($result) > 0) {
        echo "<script type='text/javascript'> alert('You had already entered your weight today'); window.close(); </script>";
        exit;
    } else {
        $email = empty($_POST["email"]) ? "" : $_POST["email"];
        $weight = empty($_POST["weight"]) ? "" : $_POST["weight"];
        $sql = "INSERT INTO weight (email, Date, Weight) VALUES ('$email','$Edate', '$weight')";
    }

} elseif ($Identifier === "E") { // Add exercise record into database
    $sql_check = "SELECT * FROM exercise WHERE Date='$Edate' AND Start='$stime' AND email='$email'";
    $result = mysqli_query($conn, $sql_check);

    if (mysqli_num_rows($result) > 0) {
        echo "<script type='text/javascript'> alert('You had already entered an entry at this time'); window.close(); </script>";
        exit;
    } else {
        $email = empty($_POST["email"]) ? "" : $_POST["email"];
        $type = empty($_POST["type"]) ? "" : $_POST["type"];
        $etime = empty($_POST["etime"]) ? "" : $_POST["etime"];
        $calory = empty($_POST["calory"]) ? "" : $_POST["calory"];
        $sql = "INSERT INTO exercise (email, Date, Type, Start, End, Calory) VALUES ('$email','$Edate', '$type', '$stime', '$etime', '$calory')";
    }

} elseif ($Identifier === "R") { // Add request record into database
    $sql_check = "SELECT * FROM request WHERE Date='$Rdate' AND email='$email'";
    $result = mysqli_query($conn, $sql_check);

    if (mysqli_num_rows($result) > 0) {
        echo "<script type='text/javascript'> alert('You had already appointed an appointment for this date'); window.location.href = 'appointment.php'; </script>";
        exit;
    } else {
        $email = empty($_POST["email"]) ? "" : $_POST["email"];
        $username = empty($_POST["Name"]) ? "" : $_POST["Name"];
        $Rdate = empty($_POST["Rdate"]) ? "" : $_POST["Rdate"];
        $Rtime = empty($_POST["Rtime"]) ? "" : $_POST["Rtime"];
        $nut = empty($_POST["nut"]) ? "" : $_POST["nut"];
        $sql = "INSERT INTO request (email, username, Date, Time, Nutritionist) VALUES ('$email', '$username', '$Rdate', '$Rtime', '$nut')";

        echo "<script type='text/javascript'> alert('You had successfully submit the appointment'); window.location.href = 'nutritionist.php'; </script>";
    }

} elseif ($Identifier === "C") {
    $sql_check = "SELECT * FROM calory WHERE Date='$Edate' AND Time='$time' AND email='$email'";
    $result = mysqli_query($conn, $sql_check);

    if (mysqli_num_rows($result) > 0) {
        echo "<script type='text/javascript'> alert('You had already entered an entry at this time'); window.close(); </script>";
        exit;
    } else {
        $email = empty($_POST["email"]) ? "" : $_POST["email"];
        $Food = empty($_POST["food"]) ? "" : $_POST["food"];
        $Calory = empty($_POST["calory"]) ? "" : $_POST["calory"];
        $sql = "INSERT INTO calory (email, Date, Time, Food, Calory) VALUES ('$email','$Edate', '$time', '$Food', '$Calory')";
    }

} else { // Add water consumption record into database
    $sql_check = "SELECT * FROM water WHERE Date='$Edate' AND Time='$time' AND email='$email'";
    $result = mysqli_query($conn, $sql_check);

    if (mysqli_num_rows($result) > 0) {
        echo "<script type='text/javascript'> alert('You had already entered an entry at this time'); window.close(); </script>";
        exit;
    } else {
        $email = empty($_POST["email"]) ? "" : $_POST["email"];
        $amount = empty($_POST["amount"]) ? "" : $_POST["amount"];
        $sql = "INSERT INTO water (email, Date, Time, Amount) VALUES ('$email','$Edate', '$time', '$amount')";
    }
}

if (mysqli_query($conn, $sql)) {
    echo "<script>
            window.opener.location.reload();
            window.close();
          </script>";
} else {
    echo "Error: " . mysqli_error($conn);
}

mysqli_close($conn);

?>
